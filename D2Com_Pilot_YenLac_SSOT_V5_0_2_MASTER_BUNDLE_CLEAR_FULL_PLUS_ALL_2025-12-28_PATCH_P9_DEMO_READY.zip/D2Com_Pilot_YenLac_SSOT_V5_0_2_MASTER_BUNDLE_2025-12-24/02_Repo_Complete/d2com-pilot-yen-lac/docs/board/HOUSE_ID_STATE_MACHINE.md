# House_ID state machine (Máy trạng thái House_ID) – V5.0.2

## 1) Vì sao cái này là KPI lõi HĐQT?
Nếu không khóa được luồng trạng thái House_ID, mày sẽ có GMV nhưng **không có hệ thống**, kiểu “ăn may”.
State machine giúp HĐQT trả lời 3 câu:
- **Tốc độ**: nhà có di chuyển đều không?
- **Nút tắc**: tắc ở SHADOW→QUALIFIED hay QUALIFIED→CLAIMED?
- **Rủi ro**: consent-risk có đang phình không?

## 2) 5 trạng thái (EN → VI)
- **SHADOW (Bóng dữ liệu)**: phát hiện nhà, chưa đủ điều kiện, chưa claim.
- **QUALIFIED (Đủ điều kiện)**: đã chuẩn hoá, có bằng chứng tối thiểu.
- **CLAIMED (Đã claim/đã consent)**: chủ nhà đã đồng ý, hệ thống được phép xử lý PII theo chính sách.
- **FINANCIAL (Đã giao dịch)**: đã phát sinh tiền.
- **GOLDEN (Hồ sơ vàng)**: hoàn chỉnh vòng đời (cross-sell/hậu mãi).

## 3) Sự kiện chuyển trạng thái (event_code)
Tham chiếu file: `registry/house_state_machine.yaml`

## 4) Quy tắc bất biến
- **Append-only**: không sửa lịch sử event.
- **Consent-first**: không có consent thì không lưu PII.
- **Revoke**: thu hồi consent phải kéo trạng thái lùi và kích hoạt xoá/ẩn PII.

## 5) Cách HĐQT soi nhanh
- QUALIFIED nhiều nhưng CLAIMED ít: kẹt xin consent (UST/CTV) hoặc quy trình OTP.
- CLAIMED có mà FINANCIAL thấp: kẹt báo giá/khảo sát/đề xuất tài chính.
- Quarantine tăng: kẹt “cổng chất lượng”, phải xử ngay trước khi đẩy GMV.
