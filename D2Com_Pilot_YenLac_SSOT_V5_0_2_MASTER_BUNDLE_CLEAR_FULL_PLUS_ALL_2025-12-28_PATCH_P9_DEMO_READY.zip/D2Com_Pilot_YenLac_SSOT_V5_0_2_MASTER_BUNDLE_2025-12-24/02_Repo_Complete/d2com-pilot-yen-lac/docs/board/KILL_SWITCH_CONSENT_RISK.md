# Kill-switch: Consent-risk (Rủi ro đồng ý/PII) – V5.0.2

## Mục tiêu
Làm rõ 2 kill-switch quan trọng nhất của pilot:
1) **Unconsented PII risk** (rủi ro PII chưa có consent)
2) **Pending consent aging hours** (giờ treo chờ consent)

English → Việt
- consent: sự đồng ý của chủ nhà
- PII (Personal Identifiable Information): thông tin định danh cá nhân (số điện thoại, CCCD, ...)

## 1) Unconsented PII risk
### Định nghĩa
Số record/event có **trường PII** (pii_*) nhưng **consent_flag != true**.

### Hành động (Action)
- Nếu phát hiện: record bị **quarantine** (bị chặn), **không được ghi vào event_log**.
- HĐQT view phải thấy số này; nếu tăng: hệ thống có người “làm ẩu” hoặc app luồng xin consent đang sai.

### Kill-switch tier (tham chiếu registry/thresholds.yaml)
- Tier 1: cảnh báo
- Tier 2: siết luồng thu thập
- Tier 3: dừng ingest + audit (kiểm tra toàn bộ)

## 2) Pending consent aging hours
### Định nghĩa
Nhà ở trạng thái **QUALIFIED** nhưng chưa sang **CLAIMED**, tuổi treo tính bằng giờ từ event QUALIFIED gần nhất.

### Ý nghĩa
- Quá lâu => UST/CTV không xin được consent, hoặc quy trình xin consent bị nghẽn.
- Nếu kéo dài: rủi ro xã hội + chính quyền “tuýt còi” vì thu thập dữ liệu không rõ ràng.

### Nguyên tắc xử lý
- >48h: ép xử lý: xin consent lại hoặc xoá dữ liệu nhạy cảm.

## 3) Nơi nhìn trên APP
- **04_Kill-switch panel**: đọc ngưỡng & log trigger.
- **09_HĐQT View**: xem số tổng hợp.
- **03_Quarantine queue**: xem record vi phạm cụ thể.
