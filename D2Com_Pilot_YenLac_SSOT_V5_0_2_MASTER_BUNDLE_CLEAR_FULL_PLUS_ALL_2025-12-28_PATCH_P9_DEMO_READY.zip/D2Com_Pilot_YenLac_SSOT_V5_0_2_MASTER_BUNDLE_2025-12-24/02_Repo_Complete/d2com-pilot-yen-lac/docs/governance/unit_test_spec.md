# Unit Test Spec (P1)

Mục tiêu: **metric_code nào lên dashboard là phải có test**. Không có test thì coi như "chưa đủ điều kiện go live".

## Quy tắc tối thiểu
- Min coverage: 90%
- Must-cover:
  - boundary_null_values (thiếu dữ liệu)
  - boundary_zero (0, chia cho 0)
  - extreme_high_values (outliers)

## Owner
- Data Engineer + QA Lead (review bắt buộc)

## Template test case
Ví dụ cho `close_rate = close_count / lead_count`:
- lead_count=0 → output=0
- lead_count=null → output=0
- lead_count=1_000_000, close_count=900_000 → 0.9
