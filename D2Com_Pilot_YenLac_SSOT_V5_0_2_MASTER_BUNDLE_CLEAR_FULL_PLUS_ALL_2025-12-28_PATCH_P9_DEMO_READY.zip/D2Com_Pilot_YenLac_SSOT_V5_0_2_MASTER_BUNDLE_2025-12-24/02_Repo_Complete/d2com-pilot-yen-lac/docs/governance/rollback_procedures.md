# Rollback Procedures (P1)

Tư duy: rollback phải như "cầu dao tổng". Không cần đẹp, chỉ cần **nhanh + đúng**.

## Registry rollback (<= 2h)
- Khi: alias collision, thresholds sai tier, fatal linter.
- Làm: revert commit + reload registry + lint PASS.

## Code rollback (<= 30m)
- Khi: payout/fraud/consent bị sai.
- Làm: tag về bản ổn định + deploy image cũ + test kill-switch.

## Data rollback (<= 4h)
- Khi: ingest sai batch.
- Làm: stop ingest + quarantine batch + backfill append-only + recompute KPI window.
