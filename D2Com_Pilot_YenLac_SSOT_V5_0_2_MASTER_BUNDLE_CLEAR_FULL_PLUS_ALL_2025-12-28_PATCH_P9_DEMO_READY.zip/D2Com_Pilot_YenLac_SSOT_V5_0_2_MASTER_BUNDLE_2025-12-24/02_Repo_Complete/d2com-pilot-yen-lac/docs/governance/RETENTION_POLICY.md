# Retention Policy (Chính sách lưu trữ & xoá dữ liệu) – V5.0.2

## 1) Mục tiêu
- **Không có consent thì không lưu PII** (thông tin định danh cá nhân).
- Tối thiểu hoá dữ liệu: lưu đúng thứ cần để vận hành + audit.
- Khi có rủi ro về consent: ưu tiên “dừng” hơn “làm liều”.

## 2) Định nghĩa nhanh (EN → VI)
- **Retention**: thời gian lưu trữ.
- **TTL (Time To Live)**: số ngày tối đa được phép giữ.
- **PII (Personally Identifiable Information)**: thông tin định danh cá nhân.
- **Revoke consent**: rút lại đồng ý.

## 3) 3 lớp dữ liệu và TTL khuyến nghị
- **audit**: 10 năm (không chứa PII thô). Ví dụ: ingest audit, hashchain.
- **long**: 5 năm (không PII). Ví dụ: House_ID, polygon mái, lịch sử trạng thái.
- **pii**: 1 năm (chỉ khi consent=true). Ví dụ: tên, SĐT, CCCD.

Nguồn chuẩn machine-readable: `registry/retention_policy.yaml`.

## 4) Workflow chuẩn
### 4.1 Pending consent (consent chưa xong)
- Metric chuẩn: `pending_consent_aging_hours`.
- >48h: cảnh báo đỏ và phải xử lý, **xin consent hoặc xoá liên quan**.
- >72h: Tier3 hard-stop theo `registry/thresholds.yaml`.

### 4.2 Revoke consent (rút đồng ý)
Khi có event `EVT_VER_CONSENT_REVOKED` (nếu hệ thống dùng):
- Ngừng ingest PII mới cho `house_id`.
- Redact PII trong view/export.
- Tạo ticket xử lý xoá PII trong kho an toàn (nếu có).

## 5) Lưu ý triển khai thực tế
- Pilot có thể chạy “không lưu PII” trong event_log, chỉ lưu token/consent_proof_ref.
- Khi triển khai thật: tách “PII Vault” (kho PII) có phân quyền, mã hoá, audit.
