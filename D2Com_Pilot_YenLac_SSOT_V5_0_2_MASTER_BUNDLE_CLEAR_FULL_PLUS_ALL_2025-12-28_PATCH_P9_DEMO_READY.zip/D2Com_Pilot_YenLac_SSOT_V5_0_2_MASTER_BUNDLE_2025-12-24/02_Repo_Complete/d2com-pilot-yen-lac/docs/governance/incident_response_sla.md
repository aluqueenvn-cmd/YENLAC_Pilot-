# Incident Response SLA (P1)

Mục tiêu: **trigger tới action không được chậm**. Pilot mà chậm là "cháy".

## SLA theo tier
- Tier 1 Warning: response 15m, action 1h
- Tier 2 Throttle: response 5m, action 30m
- Tier 3 Hard Stop: response 2m, action 15m

## Backup & escalation
- Nếu owner không phản hồi: backup_owner_role tự động nhận.
- Nếu chưa resolve theo SLA: escalation theo YAML.
