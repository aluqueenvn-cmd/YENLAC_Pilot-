# After Action Review (AAR)

- Date:
- Scenario:
- Trigger metric:
- Response time (actual vs SLA):
- Action time (actual vs SLA):
- What went well:
- What failed:
- Root cause:
- Patch needed (if any):
- Owner + deadline:
