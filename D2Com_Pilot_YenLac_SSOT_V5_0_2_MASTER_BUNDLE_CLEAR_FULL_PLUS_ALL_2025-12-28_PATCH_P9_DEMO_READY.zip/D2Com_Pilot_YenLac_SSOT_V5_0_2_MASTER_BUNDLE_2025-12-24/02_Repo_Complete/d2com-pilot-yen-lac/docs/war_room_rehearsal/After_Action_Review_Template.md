# After Action Review (AAR) — Template

## 1) What happened
- Scenario:
- Trigger metric:
- Tier:

## 2) What we expected
- Expected response_time:
- Expected action_time:
- Owner/Backup:

## 3) What actually happened
- Response time:
- Action time:
- Lý do chậm:

## 4) Root cause & fixes
- Fix (registry/code/runbook/process):
- Patch ID đề xuất:

## 5) Decision (LOCK)
- APPROVE / REJECT / NEED_MORE_EVIDENCE
