# API Contract (Hợp đồng API) – Demo V5.0.2

## Mục tiêu
- Làm “một tiếng nói chung” giữa App hiện trường ↔ Ingest.
- Giảm lỗi do format trôi (drift).

## File chuẩn
- `docs/api/OPENAPI_event_ingest_v5_0_2.yaml`

## Nguyên tắc sống còn
- **Append-only**: event log chỉ thêm.
- **Idempotency**: chống ghi trùng.
- **Consent-first**: có PII mà `consent_flag != true` => **quarantine**.

## Lưu ý
Demo hiện tại chạy ingest qua CLI/script. Khi triển khai service thật, API này là khung để build.
