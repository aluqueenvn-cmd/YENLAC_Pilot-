# API Contract (Hợp đồng API) – Demo

Trong pilot này, code ingest chạy offline bằng CSV. Nhưng để sẵn đường nâng cấp lên app thật, tao thêm bộ **OpenAPI** để:
- Dev mobile/web biết chính xác payload cần gửi.
- Data team khóa được schema và kiểm soát consent.

File chính:
- `OPENAPI_event_ingest_v5_0_2.yaml`

Lưu ý:
- Chỉ là contract demo, không khẳng định hệ thống đã expose endpoint thật.
- PII (`pii_*`) chỉ hợp lệ khi `consent_flag=true`. Nếu không, pipeline sẽ **quarantine**.
