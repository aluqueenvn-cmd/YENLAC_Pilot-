# P4 — Excel Adapters + HDQT Formula Engine + Param-linked Thresholds (2025-12-27)

## Scope
Hoàn thiện các hạng mục demo còn thiếu theo roadmap:
- **(5)** Adapter Param Master Excel → App (Streamlit)
- **(6)** Adapter Scenario Library Excel → App + Export JSON
- **(7)** HĐQT View K0–K8 chạy bằng Formula Engine (DSL V1)
- **(8)** Lint/Regression cho registry: DSL JSON + PARAM link cho thresholds + mapping

## What changed
### Code
- `code/core/param_store.py`: loader Param Master (primary + add-on), alias, apply overrides.
- `code/core/scenario_store.py`: loader Scenario Library từ Excel.
- `code/ok_computer/state.py`: session_state chuẩn hoá cho params/scenarios.
- `code/ok_computer/pages/08_Model_Lab.py`: UI chỉnh tham số theo nhóm + export append-only JSON.
- `code/ok_computer/pages/07_Scenario_Panel.py`: apply scenario + run Formula Engine + log JSONL.
- `code/ok_computer/pages/09_HDQT_View_K0-K8.py`: tiles K0–K8 dựa trên Formula Engine + threshold_eval.

### Registry
- `registry/thresholds.yaml`: cho phép `condition.value = "PARAM:<Param_Code>"`; bổ sung rule cho `ops_sla_ontime_rate`, `lead_valid_rate`; nối Tier2/Tier3 của một số metric vào Param.
- `registry/param_to_threshold_map.yaml`: map metric→Param_Code + default fallback (khi thiếu param).

### Demo inputs
- `demo_inputs/params/Param_Master_Threshold_AddOn_*.xlsx`: add-on ngưỡng (append-only).
- Copy append-only của Param Master và Scenario Library Excel vào `demo_inputs/params/` và `demo_inputs/scenario/`.

## Known limitations
- Threshold tiers (Tier1/Tier2) cho metric mới hiện là **PROVISIONAL** (chỉ để demo traffic-light). Khi có yêu cầu vận hành thực, cần quyết định ngưỡng bằng Evidence Ledger.

## Acceptance checks
- `python code/scripts/validate_registry.py --repo_root .` → pass.
- Streamlit:
  - Model Lab load default Param Master + AddOn, chỉnh param, export JSON.
  - Scenario Panel apply scenario, run metrics, log JSONL.
  - HDQT view hiển thị tile + drilldown (event_log).

