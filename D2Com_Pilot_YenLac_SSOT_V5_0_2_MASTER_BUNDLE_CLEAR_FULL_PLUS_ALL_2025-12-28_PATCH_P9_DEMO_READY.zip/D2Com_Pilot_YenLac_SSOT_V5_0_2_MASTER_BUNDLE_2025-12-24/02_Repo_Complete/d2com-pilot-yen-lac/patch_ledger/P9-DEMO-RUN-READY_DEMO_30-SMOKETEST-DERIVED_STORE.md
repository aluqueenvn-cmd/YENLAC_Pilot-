# Patch P9 – DEMO_RUN không gãy + READY_DEMO_30 pack + smoke/unit tests

Ngày: 2025-12-28 (Asia/Bangkok)

## Mục tiêu
- Vá runbook/DEMO_RUN: không gãy do template_code sai, thống nhất nguồn dữ liệu demo.
- Chốt KPI pack 25–30 KPI READY_DEMO (ở đây: READY_DEMO_30) + allowlist YAML.
- Bổ sung demo events/finance_ledger để KPI pack ra số.
- Thêm derived tables builder + smoke test + unit tests.

## Thay đổi chính (Repo)
1) **code/scripts/build_demo_store.py**
- Sửa sai chữ ký `ingest_records(...)` (đổi sang: `records = read_csv_events(...); ingest_records(repo_root=store_root, records=records, source_batch_id=...)`).
- Thêm sys.path bootstrap để chạy script standalone.
- Thêm export derived table `event_log_flat.csv` (và cố gắng export parquet nếu có engine).

2) **code/core/formula_dsl_v1.py**
- Hỗ trợ tương thích DSL:
  - chấp nhận cả `table` hoặc `source.table`
  - chấp nhận cả `entity_key` hoặc `entity_field`
- Bổ sung `start_where` cho nhóm op duration (avg/rate) để lọc start-event.

3) **demo_inputs/events/events_demo.csv**
- Bổ sung các required_keys theo `registry/events.yaml` để tránh quarantine:
  - EVT_ENG_LEAD_CREATED: thêm `lead_id`
  - EVT_TRX_SITE_SURVEY_STARTED: thêm `lead_id`, `commune_id`, `product_code`
  - EVT_FIN_CASH_COLLECTED: thêm `txn_id` (khớp finance_ledger_demo)
  - EVT_FIN_PAYOUT_SENT: thêm `payout_id`, `txn_id`
  - EVT_OPS_REWORK_OPENED: thêm `commune_id`, `product_code`

4) **code/scripts/smoke_demo_pack.py**
- Smoke test chạy KPI pack end-to-end trên `demo_out/store`.

5) **tests/**
- `test_demo_smoke_pack.py`: chạy smoke pack READY_DEMO_30.
- `test_formula_dsl_v1_duration.py`: unit test cho op duration + start_where.

6) **DEMO_RUN.md**
- Viết lại runbook theo luồng chuẩn: validate registry → build_demo_store → smoke/pytest → chạy streamlit với `D2COM_STORE_ROOT=demo_out/store`.
- Chốt template_code đúng: `A7_events_evt_star`.

## Kết quả kiểm thử (đã chạy)
- `python code/scripts/build_demo_store.py --clean` ✅
- `python code/scripts/smoke_demo_pack.py --pack READY_DEMO_30` ✅ (30 KPI ra số)
- `pytest -q` ✅ (4 tests passed)

## Tác động
- Demo chạy ổn định theo 1 nguồn dữ liệu chuẩn (`demo_out/store`).
- KPI pack READY_DEMO_30 có allowlist rõ ràng, tránh “mở máy ra 200 KPI” làm gãy.

## Ghi chú
- Parquet export trong derived là best-effort (nếu môi trường thiếu engine thì vẫn có CSV).
