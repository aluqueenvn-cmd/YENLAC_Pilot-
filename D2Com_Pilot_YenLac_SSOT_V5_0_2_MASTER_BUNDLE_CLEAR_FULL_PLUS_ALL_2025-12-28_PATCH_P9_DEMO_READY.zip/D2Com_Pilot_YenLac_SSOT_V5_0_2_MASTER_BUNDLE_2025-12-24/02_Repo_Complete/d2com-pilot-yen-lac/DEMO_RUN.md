# DEMO RUNPACK – chạy demo không gãy (V5.0.2 – Patch P9)

## Thuật ngữ (English → Việt)
- preflight: soi lỗi trước khi nạp
- ingest: nạp dữ liệu vào hệ thống
- registry-first: lấy registry làm chuẩn
- append-only: chỉ thêm, không sửa lịch sử
- idempotency_key: khóa chống ghi trùng
- quarantine: cách ly bản ghi lỗi
- smoke test: kiểm thử khói (chạy nhanh để biết có gãy không)
- unit test: kiểm thử đơn vị
- canonical store: kho dữ liệu chuẩn hoá (demo_out/store/data/...)

---

## Bước 0 – Cài môi trường
```bash
cd d2com-pilot-yen-lac
pip install -r requirements.txt
```

---

## Bước 1 – Validate registry (đừng chạy mù)
```bash
python code/scripts/validate_registry.py --repo_root .
```

---

## Bước 2 – Preflight events demo (tuỳ chọn nhưng nên làm)
**Lưu ý:** template_code đúng cho events demo là `A7_events_evt_star`.
```bash
python code/scripts/preflight_templates.py --repo_root . --template_code A7_events_evt_star --input_csv demo_inputs/events/events_demo.csv
```
Output report: `data/preflight/`.

---

## Bước 3 – Build DEMO_STORE (điểm chốt để Streamlit đọc đúng nguồn)
Script này làm 2 việc:
1) copy demo master tables vào đúng cấu trúc canonical `data/master/...`
2) ingest `events_demo.csv` thành `data/event_store/event_log.jsonl` (append-only)

```bash
python code/scripts/build_demo_store.py --clean
```

Sau khi build xong, set biến môi trường để toàn bộ app đọc từ canonical store:
```bash
export D2COM_STORE_ROOT=demo_out/store
```

---

## Bước 4 – Smoke test + Unit tests (chạy là phải ra số)
Smoke test KPI pack `READY_DEMO_30`:
```bash
python code/scripts/smoke_demo_pack.py --pack READY_DEMO_30 --build_store
```

Unit tests:
```bash
pytest -q
```

---

## Chạy OK Computer (Streamlit)
```bash
export D2COM_STORE_ROOT=demo_out/store
streamlit run code/ok_computer/app.py
```

Gợi ý page để soi nhanh:
- Registry Viewer (xem SSOT)
- Gate Monitor (theo dõi pass/fail)
- Quarantine Queue (xem lỗi ingest)
- Kill-Switch Panel (cầu dao ngắt)
- Scenario Explorer / Param Explorer (nếu bật)

---

## Gỡ rối nhanh
- Nếu app vẫn đọc dữ liệu cũ: kiểm tra `echo $D2COM_STORE_ROOT` có đúng `demo_out/store` chưa.
- Nếu smoke test FAIL: đọc log in ra để biết metric nào ra `None` (thường do thiếu event hoặc sai field).
