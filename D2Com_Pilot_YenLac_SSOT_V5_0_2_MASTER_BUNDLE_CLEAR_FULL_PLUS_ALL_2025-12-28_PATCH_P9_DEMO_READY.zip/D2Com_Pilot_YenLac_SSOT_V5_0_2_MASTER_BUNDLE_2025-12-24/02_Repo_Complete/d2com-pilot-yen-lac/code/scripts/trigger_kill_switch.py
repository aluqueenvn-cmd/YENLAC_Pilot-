#!/usr/bin/env python3
"""trigger_kill_switch.py — Kill-switch dispatcher (V5.0.2)

Script này là "cầu dao" để đẩy sự kiện kill-switch ra ngoài.
Trong demo: ghi JSONL vào file theo registry/alert_routes.yaml và in stdout.

English → Việt:
- kill-switch: công tắc ngắt khẩn (dừng hệ thống theo ngưỡng)
- dispatcher: bộ điều phối
"""

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

# Ensure imports work when running as script
CODE_DIR = Path(__file__).resolve().parents[1]
if str(CODE_DIR) not in sys.path:
    sys.path.insert(0, str(CODE_DIR))

from core.alerting import emit_alert


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo_root", default=".")
    ap.add_argument("--metric_code", required=True)
    ap.add_argument("--value", required=True)
    ap.add_argument(
        "--tier",
        choices=["TIER_1_WARNING", "TIER_2_THROTTLE", "TIER_3_HARD_STOP"],
        required=True,
    )
    ap.add_argument("--reason", default="")
    args = ap.parse_args()

    payload = {
        "ts": datetime.utcnow().isoformat() + "Z",
        "metric_code": args.metric_code,
        "value": args.value,
        "tier": args.tier,
        "reason": args.reason,
        "action": "TRIGGER_KILL_SWITCH",
    }

    repo_root = Path(args.repo_root).resolve()
    emit_alert(repo_root, "kill_switch", payload)

    print(json.dumps(payload, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
