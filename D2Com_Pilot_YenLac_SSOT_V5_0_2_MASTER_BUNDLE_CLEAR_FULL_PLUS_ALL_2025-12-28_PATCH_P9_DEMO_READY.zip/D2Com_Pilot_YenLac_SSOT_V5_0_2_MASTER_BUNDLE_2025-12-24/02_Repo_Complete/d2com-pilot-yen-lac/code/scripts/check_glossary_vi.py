"""check_glossary_vi.py

Hard gate: ensure all core terms have Vietnamese (vi) and definition_vi where required.

Checks:
  - All metric_code in registry/metrics.csv exist in glossary.csv and have non-empty vi.
  - All event_code in registry/events.yaml exist in glossary.csv and have non-empty vi.
  - evidence_code, role_code, canonical states have Vietnamese.
  - All glossary rows must have non-empty 'vi'.

Exit code:
  0 if PASS, 1 if FAIL.
"""

from __future__ import annotations

import csv
from pathlib import Path

import pandas as pd
import yaml


REPO_ROOT = Path(__file__).resolve().parents[2]
REGISTRY = REPO_ROOT / "registry"


def load_glossary_index() -> dict[str, dict[str, str]]:
    p = REGISTRY / "glossary.csv"
    if not p.exists():
        raise FileNotFoundError("registry/glossary.csv not found. Run build_glossary.py first.")
    out: dict[str, dict[str, str]] = {}
    with open(p, "r", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            code = (row.get("term_code") or "").strip()
            if code:
                out[code.lower()] = {k: (row.get(k) or "").strip() for k in row.keys()}
    return out


def fail(msg: str) -> None:
    print("❌ FAIL:", msg)
    raise SystemExit(1)


def main() -> None:
    g = load_glossary_index()

    # 1) Every glossary row must have Vietnamese
    missing_vi = [k for k, v in g.items() if not v.get("vi")]
    if missing_vi:
        fail(f"Glossary thiếu tiếng Việt cho {len(missing_vi)} term (ví dụ: {missing_vi[:10]})")

    # 2) Metrics coverage
    m = pd.read_csv(REGISTRY / "metrics.csv")
    metric_codes = [str(x).strip() for x in m["metric_code"].tolist() if str(x).strip()]
    not_found = [c for c in metric_codes if c.lower() not in g]
    if not_found:
        fail(f"Glossary thiếu metric_code: {not_found[:15]}")
    missing_metric_vi = [c for c in metric_codes if not g[c.lower()].get("vi")]
    if missing_metric_vi:
        fail(f"Glossary thiếu tiếng Việt cho metric_code: {missing_metric_vi[:15]}")

    # 3) Events coverage
    events_obj = yaml.safe_load((REGISTRY / "events.yaml").read_text(encoding="utf-8"))
    ev_codes = [str(e.get("event_code") or "").strip() for e in events_obj.get("events", [])]
    ev_codes = [c for c in ev_codes if c]
    not_found = [c for c in ev_codes if c.lower() not in g]
    if not_found:
        fail(f"Glossary thiếu event_code: {not_found[:15]}")
    missing_event_vi = [c for c in ev_codes if not g[c.lower()].get("vi")]
    if missing_event_vi:
        fail(f"Glossary thiếu tiếng Việt cho event_code: {missing_event_vi[:15]}")

    # 4) Evidence + roles + states from spec
    spec = events_obj.get("spec", {})
    # evidence
    ev_cat = spec.get("evidence_catalog", {}) or {}
    evidence_codes = []
    for _, items in ev_cat.items():
        for it in items:
            c = str(it.get("evidence_code") or "").strip()
            if c:
                evidence_codes.append(c)
    for c in evidence_codes:
        if c.lower() not in g:
            fail(f"Glossary thiếu evidence_code: {c}")

    # roles
    roles = [str(r.get("role_code") or "").strip() for r in (spec.get("roles") or [])]
    roles = [c for c in roles if c]
    for c in roles:
        if c.lower() not in g:
            fail(f"Glossary thiếu role_code: {c}")

    # states
    canon = (spec.get("canonical_states") or {})
    states = [str(s).strip() for s in (canon.get("house_lifecycle") or [])]
    states = [c for c in states if c]
    for c in states:
        if c.lower() not in g:
            fail(f"Glossary thiếu house lifecycle state: {c}")

    print("✅ PASS: glossary coverage + Vietnamese labels OK")


if __name__ == "__main__":
    main()
