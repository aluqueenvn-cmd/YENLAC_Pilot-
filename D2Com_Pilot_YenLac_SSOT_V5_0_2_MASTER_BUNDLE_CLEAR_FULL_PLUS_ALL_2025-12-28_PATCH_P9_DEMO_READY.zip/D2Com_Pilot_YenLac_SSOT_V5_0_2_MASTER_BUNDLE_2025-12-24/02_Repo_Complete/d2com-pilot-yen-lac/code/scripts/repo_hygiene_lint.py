#!/usr/bin/env python3
"""repo_hygiene_lint.py (V5.0.2)

Lint nhẹ để tránh lỗi khi copy repo qua nhiều OS:
- Phát hiện file trùng tên theo kiểu case-insensitive (Windows hay dính)
- Báo file có ký tự lạ hoặc khoảng trắng ở cuối

English → Việt:
- lint: kiểm tra tự động
- case-insensitive: không phân biệt hoa/thường
"""

from __future__ import annotations

import argparse
from pathlib import Path


def is_weird(name: str) -> bool:
    return name.endswith(' ') or ('\t' in name) or ('\r' in name) or ('\n' in name)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo_root', required=True)
    ap.add_argument('--max_depth', type=int, default=6)
    args = ap.parse_args()

    repo_root = Path(args.repo_root).resolve()
    collisions = {}
    weird = []

    for p in repo_root.rglob('*'):
        if p.is_dir():
            # depth guard
            try:
                rel = p.relative_to(repo_root)
                if len(rel.parts) > args.max_depth:
                    continue
            except Exception:
                pass
            continue

        try:
            rel = p.relative_to(repo_root)
        except Exception:
            continue

        key = str(rel).lower()
        collisions.setdefault(key, []).append(str(rel))

        if is_weird(p.name):
            weird.append(str(rel))

    dup = {k: v for k, v in collisions.items() if len(v) > 1}

    ok = True
    if dup:
        ok = False
        print('ERROR: case-insensitive collisions found:')
        for k, v in sorted(dup.items()):
            print(' -', k)
            for item in v:
                print('   *', item)

    if weird:
        ok = False
        print('ERROR: weird filenames found:')
        for x in weird:
            print(' -', x)

    if ok:
        print('OK: repo hygiene check passed')
        return 0

    return 2


if __name__ == '__main__':
    raise SystemExit(main())
