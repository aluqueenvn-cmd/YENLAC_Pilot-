"""build_glossary.py

Generate SSOT glossary (Anh–Việt) from registry files.

Output:
  - registry/glossary.csv

Design goals:
  - Registry-first: derive from registry/*.
  - Do NOT modify existing registries. Only create/overwrite glossary.csv.
  - Cover: base terms, metric_code, event_code, evidence_code, role_code,
    canonical states, gate codes/items, kill-switch tiers.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import pandas as pd
import yaml


REPO_ROOT = Path(__file__).resolve().parents[2]
REGISTRY_DIR = REPO_ROOT / "registry"


@dataclass
class GlossaryRow:
    term_code: str
    en: str
    vi: str
    definition_en: str = ""
    definition_vi: str = ""
    unit: str = ""
    example: str = ""
    source: str = "registry"

    def as_dict(self) -> Dict[str, str]:
        return {
            "term_code": self.term_code,
            "en": self.en,
            "vi": self.vi,
            "definition_en": self.definition_en,
            "definition_vi": self.definition_vi,
            "unit": self.unit,
            "example": self.example,
            "source": self.source,
        }


def _safe_yaml(path: Path) -> Any:
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def _add(rows: Dict[str, GlossaryRow], row: GlossaryRow) -> None:
    key = row.term_code.strip()
    if not key:
        return
    # Do not overwrite if existing row already has Vietnamese filled.
    if key in rows and (rows[key].vi or rows[key].definition_vi):
        return
    rows[key] = row


def base_terms() -> List[GlossaryRow]:
    """Curated base terms used throughout UI/docs."""
    return [
        GlossaryRow(
            term_code="SSOT",
            en="Single Source of Truth",
            vi="Nguồn chuẩn duy nhất",
            definition_vi="Một nguồn dữ liệu/định nghĩa được coi là chuẩn để toàn hệ thống dùng chung; tránh 2 hệ quy chiếu.",
            example="Registry (metrics/events/thresholds) là SSOT.",
            source="base_terms",
        ),
        GlossaryRow(
            term_code="append-only",
            en="Append-only",
            vi="Chỉ ghi thêm, không sửa lịch sử",
            definition_vi="Không chỉnh sửa bản ghi đã sinh; mọi thay đổi được ghi thêm như một bản ghi mới để audit.",
            example="Event log là append-only.",
            source="base_terms",
        ),
        GlossaryRow(
            term_code="event",
            en="Event",
            vi="Sự kiện",
            definition_vi="Một bản ghi chuẩn hoá mô tả việc đã xảy ra (ai, khi nào, ở đâu, tác động gì).",
            example="EVT_VER_ID_VERIFIED",
            source="base_terms",
        ),
        GlossaryRow(
            term_code="preflight",
            en="Preflight check",
            vi="Tiền kiểm",
            definition_vi="Kiểm tra dữ liệu trước khi nạp vào hệ (schema/required fields/consistency).",
            example="Chạy preflight cho A7_events_evt_star.",
            source="base_terms",
        ),
        GlossaryRow(
            term_code="ingest",
            en="Ingest",
            vi="Nạp dữ liệu",
            definition_vi="Đưa dữ liệu đầu vào (CSV/JSONL) vào event store theo quy tắc registry.",
            example="ingest_events.py",
            source="base_terms",
        ),
        GlossaryRow(
            term_code="quarantine",
            en="Quarantine",
            vi="Cách ly dữ liệu lỗi",
            definition_vi="Tập hợp record bị chặn do sai quy tắc; cần sửa hoặc xử lý theo policy.",
            example="Invalid phone format; Missing consent.",
            source="base_terms",
        ),
        GlossaryRow(
            term_code="kill-switch",
            en="Kill switch",
            vi="Cầu dao ngắt",
            definition_vi="Cơ chế ngắt/throttle hệ thống khi vượt ngưỡng rủi ro để tránh thiệt hại lan rộng.",
            example="unconsented_pii_risk > 0 ⇒ HARD STOP.",
            source="base_terms",
        ),
        GlossaryRow(
            term_code="PII",
            en="Personally Identifiable Information",
            vi="Thông tin định danh cá nhân",
            definition_vi="Dữ liệu có thể xác định một cá nhân (số điện thoại, CCCD, địa chỉ cụ thể...).",
            example="phone, id_number",
            source="base_terms",
        ),
        GlossaryRow(
            term_code="consent",
            en="Consent",
            vi="Đồng ý cho phép lưu PII",
            definition_vi="Sự đồng ý của chủ thể dữ liệu cho phép thu thập/lưu/ xử lý PII.",
            example="EVT_VER_CONSENT_OTP_VERIFIED",
            source="base_terms",
        ),
        GlossaryRow(
            term_code="SLA",
            en="Service Level Agreement",
            vi="Cam kết mức dịch vụ",
            definition_vi="Cam kết về thời gian/chất lượng xử lý; vi phạm SLA thì phạt hoặc phải làm lại.",
            example="SLA install ≤ 7 ngày",
            source="base_terms",
        ),
        GlossaryRow(
            term_code="FTR",
            en="First-Time-Right",
            vi="Làm đúng ngay lần đầu",
            definition_vi="Tỷ lệ công việc đạt chuẩn nghiệm thu ngay lần đầu, không cần làm lại.",
            example="adgpro_pass_rate",
            source="base_terms",
        ),
    ]


def add_metrics(rows: Dict[str, GlossaryRow]) -> None:
    p = REGISTRY_DIR / "metrics.csv"
    if not p.exists():
        return
    df = pd.read_csv(p)
    for _, r in df.iterrows():
        code = str(r.get("metric_code") or "").strip()
        if not code:
            continue
        name_en = str(r.get("metric_name_en") or code)
        name_vi = str(r.get("metric_name_vi") or "").strip()
        def_vi = str(r.get("definition_vi") or "").strip()
        unit = str(r.get("unit") or "").strip()
        k_level = str(r.get("k_level") or "").strip()
        # If metric_name_vi is just the code, prefer a friendlier label based on definition.
        if not name_vi or name_vi == code:
            name_vi = def_vi.split(".")[0].strip() if def_vi else code
        _add(
            rows,
            GlossaryRow(
                term_code=code,
                en=name_en,
                vi=name_vi,
                definition_vi=def_vi,
                unit=unit,
                example=f"{k_level} / unit={unit}",
                source="metrics.csv",
            ),
        )


def add_events(rows: Dict[str, GlossaryRow]) -> None:
    p = REGISTRY_DIR / "events.yaml"
    if not p.exists():
        return
    obj = _safe_yaml(p)
    events = obj.get("events", [])
    for e in events:
        code = str(e.get("event_code") or "").strip()
        if not code:
            continue
        name_vi = str(e.get("name_vi") or "").strip()
        # Some registries omit English; keep en as code for stability.
        name_en = str(e.get("name_en") or code).strip()
        required = e.get("required_keys") or []
        evidence = e.get("evidence_required") or []
        state = e.get("state_impact") or {}
        def_vi = ""
        if required:
            def_vi += f"Bắt buộc: {', '.join(required)}. "
        if evidence:
            def_vi += f"Bằng chứng: {', '.join(evidence)}. "
        if state:
            try:
                hl = (state.get("house_lifecycle") or {})
                if hl:
                    def_vi += f"Tác động trạng thái: {hl.get('from')} → {hl.get('to')}. "
            except Exception:
                pass
        _add(
            rows,
            GlossaryRow(
                term_code=code,
                en=name_en,
                vi=name_vi or code,
                definition_vi=def_vi.strip(),
                unit="event",
                example=f"required={required} evidence={evidence}",
                source="events.yaml",
            ),
        )

    # Evidence catalog + roles + canonical states are in spec
    spec = obj.get("spec", {})
    # Evidence codes
    ev_cat = (spec.get("evidence_catalog") or {})
    for group, items in ev_cat.items():
        for it in items:
            code = str(it.get("evidence_code") or "").strip()
            if not code:
                continue
            _add(
                rows,
                GlossaryRow(
                    term_code=code,
                    en=code,
                    vi=str(it.get("vi") or code),
                    definition_vi=f"Bằng chứng nhóm '{group}'.",
                    unit="evidence",
                    source="events.yaml:spec.evidence_catalog",
                ),
            )

    # Roles
    for r in (spec.get("roles") or []):
        code = str(r.get("role_code") or "").strip()
        if not code:
            continue
        _add(
            rows,
            GlossaryRow(
                term_code=code,
                en=code,
                vi=str(r.get("vi") or code),
                definition_vi="Vai trò trong hệ thống.",
                unit="role",
                source="events.yaml:spec.roles",
            ),
        )

    # Canonical states
    canon = (spec.get("canonical_states") or {})
    hl_states = (canon.get("house_lifecycle") or [])
    state_vi = {
        "SHADOW": "SHADOW (Bóng) – có nhà nhưng chưa đủ điều kiện",
        "QUALIFIED": "QUALIFIED (Đủ điều kiện) – đã xác minh cơ bản",
        "CLAIMED": "CLAIMED (Đã claim) – đã có người/đơn vị nhận xử lý",
        "FINANCIAL": "FINANCIAL (Tài chính) – có giao dịch/đối soát",
        "GOLDEN": "GOLDEN (Vàng) – hồ sơ sạch + khai thác dài hạn",
    }
    for s in hl_states:
        s = str(s).strip()
        if not s:
            continue
        _add(
            rows,
            GlossaryRow(
                term_code=s,
                en=s,
                vi=state_vi.get(s, s),
                definition_vi="Trạng thái vòng đời House_ID.",
                unit="state",
                source="events.yaml:spec.canonical_states",
            ),
        )


def add_thresholds(rows: Dict[str, GlossaryRow]) -> None:
    p = REGISTRY_DIR / "thresholds.yaml"
    if not p.exists():
        return
    obj = _safe_yaml(p)
    for t in (obj.get("thresholds") or []):
        metric_code = str(t.get("metric_code") or "").strip()
        if not metric_code:
            continue
        notes = str(t.get("notes") or "").strip()
        _add(
            rows,
            GlossaryRow(
                term_code=f"threshold::{metric_code}",
                en=f"Threshold for {metric_code}",
                vi=f"Ngưỡng cảnh báo cho {metric_code}",
                definition_vi=notes,
                unit=str(t.get("unit") or ""),
                example=str(t.get("tiers") or "")[:200],
                source="thresholds.yaml",
            ),
        )

        # Tier labels
        for tier in (t.get("tiers") or []):
            tier_code = str(tier.get("tier") or "").strip()
            if not tier_code:
                continue
            vi_map = {
                "TIER_3_HARD_STOP": "TIER 3 (Đỏ) – Ngắt hệ thống",
                "TIER_2_THROTTLE": "TIER 2 (Vàng) – Siết/tạm giảm tải",
                "TIER_1_WARNING": "TIER 1 (Xanh/Vàng) – Cảnh báo",
            }
            _add(
                rows,
                GlossaryRow(
                    term_code=tier_code,
                    en=tier_code,
                    vi=vi_map.get(tier_code, tier_code),
                    definition_vi="Mức phản ứng theo ngưỡng.",
                    unit="tier",
                    source="thresholds.yaml:tiers",
                ),
            )


def add_gates(rows: Dict[str, GlossaryRow]) -> None:
    p = REGISTRY_DIR / "gate_matrix.yaml"
    if not p.exists():
        return
    obj = _safe_yaml(p)
    gates = (obj.get("gates") or {})
    for gate_code, items in gates.items():
        _add(
            rows,
            GlossaryRow(
                term_code=gate_code,
                en=gate_code,
                vi=f"Cổng kiểm {gate_code}",
                definition_vi="Danh sách điều kiện bắt buộc trước khi đi tiếp.",
                unit="gate",
                source="gate_matrix.yaml",
            ),
        )
        for it in items or []:
            item_name = str(it.get("item") or "").strip()
            if not item_name:
                continue
            key = f"{gate_code}::{item_name[:60]}"
            _add(
                rows,
                GlossaryRow(
                    term_code=key,
                    en=item_name,
                    vi=item_name,
                    definition_vi=str(it.get("action") or "").strip(),
                    source="gate_matrix.yaml:items",
                ),
            )


def write_glossary(rows: Dict[str, GlossaryRow], out_path: Path) -> int:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "term_code",
        "en",
        "vi",
        "definition_en",
        "definition_vi",
        "unit",
        "example",
        "source",
    ]
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for k in sorted(rows.keys(), key=lambda x: x.lower()):
            w.writerow(rows[k].as_dict())
    return len(rows)


def main() -> None:
    rows: Dict[str, GlossaryRow] = {}
    for r in base_terms():
        _add(rows, r)
    add_metrics(rows)
    add_events(rows)
    add_thresholds(rows)
    add_gates(rows)

    out = REGISTRY_DIR / "glossary.csv"
    n = write_glossary(rows, out)
    print(f"✅ Generated registry/glossary.csv with {n} terms")


if __name__ == "__main__":
    main()
