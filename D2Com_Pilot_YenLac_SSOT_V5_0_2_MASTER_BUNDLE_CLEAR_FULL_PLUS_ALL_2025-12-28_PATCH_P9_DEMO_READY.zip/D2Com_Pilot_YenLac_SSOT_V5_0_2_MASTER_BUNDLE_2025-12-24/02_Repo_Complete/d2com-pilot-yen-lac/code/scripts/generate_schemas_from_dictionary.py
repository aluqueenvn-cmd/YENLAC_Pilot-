#!/usr/bin/env python3
"""generate_schemas_from_dictionary.py (V5.0.2)

Mục tiêu:
- Từ registry/data_dictionary.yaml sinh ra schema tối giản để máy validate.
- KHÔNG ghi đè templates/schema_generated/* (giữ nguyên lịch sử).
- Output: templates/schema_from_dictionary/event_record.schema.yaml

Thuật ngữ:
- data dictionary (từ điển dữ liệu): danh sách field + kiểu + quy tắc
- schema: khuôn dữ liệu để validate
"""

from __future__ import annotations

import argparse
from pathlib import Path
import yaml


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo_root", required=True)
    ap.add_argument(
        "--out",
        default="templates/schema_from_dictionary/event_record.schema.yaml",
        help="Đường dẫn schema output (tương đối từ repo root)",
    )
    args = ap.parse_args()

    repo_root = Path(args.repo_root).resolve()
    dd_path = repo_root / "registry" / "data_dictionary.yaml"
    if not dd_path.exists():
        raise SystemExit(f"missing {dd_path}")

    dd = yaml.safe_load(dd_path.read_text(encoding="utf-8"))
    fields = dd.get("fields", []) or []

    props = {}
    required = []
    for f in fields:
        name = f["field"]
        typ = f.get("type", "string")
        props[name] = {
            "type": typ,
            "description_vi": f.get("description_vi", ""),
            "pii_class": f.get("pii_class", "none"),
            "retention_class": f.get("retention_class", "long"),
        }
        if f.get("allowed"):
            props[name]["allowed"] = f.get("allowed")
        if f.get("unit"):
            props[name]["unit"] = f.get("unit")
        if f.get("required") is True:
            required.append(name)

    schema = {
        "schema_id": "event_record",
        "version": "v5.0.2",
        "notes": "Generated from registry/data_dictionary.yaml. Minimal schema for validation.",
        "required": required,
        "properties": props,
    }

    out_path = repo_root / args.out
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(yaml.safe_dump(schema, sort_keys=False, allow_unicode=True), encoding="utf-8")
    print(f"✅ wrote {out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
