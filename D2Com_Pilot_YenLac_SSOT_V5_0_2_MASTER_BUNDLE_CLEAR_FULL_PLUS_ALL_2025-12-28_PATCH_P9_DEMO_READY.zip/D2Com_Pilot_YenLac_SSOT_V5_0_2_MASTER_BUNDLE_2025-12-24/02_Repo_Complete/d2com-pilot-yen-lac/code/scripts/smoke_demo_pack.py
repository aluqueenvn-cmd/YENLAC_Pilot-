#!/usr/bin/env python3
"""smoke_demo_pack.py – Smoke test end-to-end KPI pack trên DEMO_STORE.

English -> Việt:
- smoke test: kiểm thử khói (chạy nhanh để chắc chắn không gãy)
- KPI pack: gói KPI (allowlist metric_code)
- canonical store: kho dữ liệu chuẩn hoá (demo_out/store/data/...)

Usage:
  python code/scripts/smoke_demo_pack.py --pack READY_DEMO_30 --build_store

Exit codes:
  0 = PASS
  1 = FAIL
"""

from __future__ import annotations

import argparse
import math
import os
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

import yaml

# Ensure imports work when running as a standalone script.
CODE_DIR = Path(__file__).resolve().parents[1]
if str(CODE_DIR) not in sys.path:
    sys.path.insert(0, str(CODE_DIR))

from core.formula_engine import eval_metrics


def load_pack_metric_codes(repo_root: Path, pack_code: str) -> List[str]:
    pack_path = repo_root / "registry" / "kpi_packs" / f"{pack_code}.yaml"
    if not pack_path.exists():
        raise SystemExit(f"Missing pack: {pack_path}")
    obj = yaml.safe_load(pack_path.read_text(encoding="utf-8")) or {}
    codes = obj.get("metric_codes") or []
    out: List[str] = []
    for x in codes:
        s = str(x).strip()
        if s:
            out.append(s)
    return out


def is_bad_number(v: Any) -> bool:
    if v is None:
        return True
    if isinstance(v, bool):
        return False
    if isinstance(v, (int, float)):
        if isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
            return True
        return False
    # allow strings that look like numbers
    if isinstance(v, str):
        s = v.strip()
        if not s:
            return True
        try:
            f = float(s)
            return math.isnan(f) or math.isinf(f)
        except Exception:
            return True
    return True


def build_demo_store(repo_root: Path, clean: bool = True) -> None:
    cmd = [sys.executable, str(repo_root / "code" / "scripts" / "build_demo_store.py")]
    if clean:
        cmd.append("--clean")
    res = subprocess.run(cmd, cwd=str(repo_root), capture_output=True, text=True)
    if res.returncode != 0:
        raise SystemExit(f"build_demo_store failed.\nstdout:\n{res.stdout}\nstderr:\n{res.stderr}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pack", default="READY_DEMO_30")
    ap.add_argument("--build_store", action="store_true", help="Build demo_out/store before evaluating")
    ap.add_argument("--no_clean", action="store_true", help="When building, do not delete existing store")
    args = ap.parse_args()

    repo_root = Path(__file__).resolve().parents[2]
    store_root = repo_root / "demo_out" / "store"

    if args.build_store:
        build_demo_store(repo_root, clean=(not args.no_clean))

    os.environ["D2COM_STORE_ROOT"] = str(store_root)

    metric_codes = load_pack_metric_codes(repo_root, args.pack)
    results = eval_metrics(repo_root=repo_root, metric_codes=set(metric_codes))

    failed: List[Tuple[str, str]] = []
    for code in metric_codes:
        r = results.get(code)
        if r is None:
            failed.append((code, "missing_formula"))
            continue
        if is_bad_number(r.value):
            failed.append((code, f"bad_value:{r.value}|note={r.note}"))

    if failed:
        print(f"FAIL pack={args.pack} store={store_root}")
        for code, why in failed:
            print(f"- {code}: {why}")
        return 1

    print(f"PASS pack={args.pack} store={store_root} metrics={len(metric_codes)}")
    for code in metric_codes:
        r = results.get(code)
        print(f"- {code} = {r.value} ({r.note})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
