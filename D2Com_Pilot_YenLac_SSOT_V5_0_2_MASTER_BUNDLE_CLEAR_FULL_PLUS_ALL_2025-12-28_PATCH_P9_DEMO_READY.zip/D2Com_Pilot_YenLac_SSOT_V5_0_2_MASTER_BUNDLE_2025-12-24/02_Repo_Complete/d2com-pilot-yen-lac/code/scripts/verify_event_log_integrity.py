#!/usr/bin/env python3
"""verify_event_log_integrity.py (V5.0.2)

Kiểm tra tính toàn vẹn append-only bằng hashchain.

English → Việt:
- hash chain: chuỗi băm (mỗi bản ghi phụ thuộc hash trước)
- integrity: tính toàn vẹn

Cách chạy:
  python code/scripts/verify_event_log_integrity.py --repo_root .
"""

from __future__ import annotations

import argparse, json, hashlib
from pathlib import Path


def sha(prev_hash: str, event_obj: dict) -> str:
    payload = json.dumps(event_obj, ensure_ascii=False, sort_keys=True)
    h = hashlib.sha256()
    h.update(prev_hash.encode('utf-8'))
    h.update(b'|')
    h.update(payload.encode('utf-8'))
    return h.hexdigest()


def read_jsonl(path: Path):
    if not path.exists():
        return []
    out=[]
    with path.open('r', encoding='utf-8') as f:
        for line in f:
            line=line.strip()
            if not line:
                continue
            out.append(json.loads(line))
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo_root', required=True)
    ap.add_argument('--event_log', default='data/event_store/event_log.jsonl')
    ap.add_argument('--hashchain', default='data/event_store/event_log_hashchain.jsonl')
    args = ap.parse_args()

    repo_root = Path(args.repo_root).resolve()
    ev_path = repo_root / args.event_log
    hc_path = repo_root / args.hashchain

    events = read_jsonl(ev_path)
    chain = read_jsonl(hc_path)

    if not events:
        print('OK: no events')
        return 0
    if not chain:
        raise SystemExit('ERROR: missing hashchain file, run ingest to generate')

    # Build index event_log_id -> event
    ev_by_id = {e.get('event_log_id'): e for e in events if e.get('event_log_id')}

    prev='GENESIS'
    checked=0
    for entry in chain:
        eid = entry.get('event_log_id')
        if not eid:
            continue
        if entry.get('prev_hash') != prev:
            raise SystemExit(f"ERROR: prev_hash mismatch at {eid}")
        ev = ev_by_id.get(eid)
        if not ev:
            raise SystemExit(f"ERROR: event missing for hashchain id {eid}")
        expected = sha(prev, ev)
        if entry.get('hash') != expected:
            raise SystemExit(f"ERROR: hash mismatch at {eid}")
        prev = expected
        checked += 1

    print(f"OK: verified {checked} entries")
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
