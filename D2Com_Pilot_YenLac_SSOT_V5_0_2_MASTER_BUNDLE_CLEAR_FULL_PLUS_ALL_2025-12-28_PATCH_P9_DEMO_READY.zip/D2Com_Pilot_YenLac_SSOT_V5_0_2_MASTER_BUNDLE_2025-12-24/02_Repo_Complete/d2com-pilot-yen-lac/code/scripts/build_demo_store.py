"""Build a self-contained canonical demo store under demo_out/store.

Why:
- demo_inputs is convenient, but KPI DSL and board metrics should read from the canonical layout:
  data/event_store/event_log.jsonl + data/master/... tables.
- This script copies demo master tables into canonical locations and ingests demo events into
  an append-only JSONL event store (plus a couple of derived artifacts).

English -> Việt:
- store_root: thư mục gốc dữ liệu (chứa thư mục con data/)
- canonical store: kho dữ liệu chuẩn hoá theo cấu trúc data/

Usage:
  python -m scripts.build_demo_store --clean

After running:
  export D2COM_STORE_ROOT=demo_out/store
  streamlit run code/ok_computer/app.py
"""

from __future__ import annotations

import argparse
import os
import shutil
import sys
from pathlib import Path

import pandas as pd

# Ensure imports work when running as a standalone script.
# English -> Việt: thêm đường dẫn 'code/' vào sys.path để import core/ok_computer.
CODE_DIR = Path(__file__).resolve().parents[1]
if str(CODE_DIR) not in sys.path:
    sys.path.insert(0, str(CODE_DIR))

from core.ingest_pipeline import read_csv_events, ingest_records
from core.asset_loader import AssetLoader


def build_demo_store(repo_root: Path, store_root: Path, clean: bool = False) -> None:
    if clean and store_root.exists():
        shutil.rmtree(store_root)

    # 1) canonical folders
    (store_root / "data").mkdir(parents=True, exist_ok=True)

    # 2) copy registry (nice to have for debugging / demo)
    src_registry = repo_root / "registry"
    dst_registry = store_root / "registry"
    if src_registry.exists():
        shutil.copytree(src_registry, dst_registry, dirs_exist_ok=True)

    # 3) copy master tables from demo_inputs into canonical data/master/... paths
    copies = [
        (repo_root / "demo_inputs/hard/house_master_demo.csv", store_root / "data/master/hard/house_master.csv"),
        (repo_root / "demo_inputs/hard/job_master_demo.csv", store_root / "data/master/hard/job_master.csv"),
        (repo_root / "demo_inputs/hard/actor_master_demo.csv", store_root / "data/master/hard/actor_master.csv"),
        (repo_root / "demo_inputs/hard/finance_ledger_demo.csv", store_root / "data/master/hard/finance_ledger.csv"),
        (repo_root / "demo_inputs/soft/intel_radar_snapshot_demo.csv", store_root / "data/master/soft/intel_radar_snapshot.csv"),
    ]
    for src, dst in copies:
        if not src.exists():
            continue
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

    # 4) ingest demo events into canonical event store
    events_csv = repo_root / "demo_inputs/events/events_demo.csv"
    if not events_csv.exists():
        raise FileNotFoundError(f"Missing demo events CSV: {events_csv}")

    records = read_csv_events(events_csv)
    res = ingest_records(
        repo_root=store_root,
        records=records,
        source_batch_id="events_demo.csv",
        strip_unconsented_pii=True,
    )
    if res.errors:
        raise RuntimeError("Ingest failed: " + "; ".join(res.errors))

    # 5) build a derived artifact (flat parquet) for fast exploration
    os.environ["D2COM_STORE_ROOT"] = str(store_root)
    loader = AssetLoader(repo_root=repo_root)
    la_ev = loader.load_event_log_flat()
    ev = la_ev.df

    derived_dir = store_root / "data/derived"
    derived_dir.mkdir(parents=True, exist_ok=True)
    try:
        ev.to_parquet(derived_dir / "event_log_flat.parquet", index=False)
    except Exception:
        # parquet optional; keep demo working even if pyarrow isn't present
        ev.to_csv(derived_dir / "event_log_flat.csv", index=False, encoding="utf-8-sig")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--clean", action="store_true", help="Remove demo_out/store before rebuilding")
    args = parser.parse_args()

    repo_root = Path(__file__).resolve().parents[2]
    store_root = repo_root / "demo_out" / "store"

    build_demo_store(repo_root=repo_root, store_root=store_root, clean=args.clean)
    print(f"OK. Demo store built at: {store_root}")


if __name__ == "__main__":
    main()
