#!/usr/bin/env python3
"""run_formula_engine.py - Run formula_engine and print a KPI snapshot.

English -> Viet:
- snapshot: ban chup nhanh (chot so theo thoi diem)

Usage:
  python code/scripts/run_formula_engine.py --repo_root . --only_ready_demo 1
"""

import argparse
import json
from datetime import datetime
from pathlib import Path

from core.formula_engine import eval_metrics


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo_root', required=True)
    ap.add_argument('--only_ready_demo', default='1')
    ap.add_argument('--out', default='data/kpi_pulse/kpi_from_formulas.json')
    args = ap.parse_args()

    repo_root = Path(args.repo_root).resolve()

    metric_codes = None
    if args.only_ready_demo in {'1','true','True','yes','y'}:
        # pick metric_codes where formula status == READY_DEMO
        import pandas as pd
        df = pd.read_csv(repo_root/'registry'/'formulas.csv')
        metric_codes = set(df[df['status']=='READY_DEMO']['metric_code'].tolist())

    res = eval_metrics(repo_root, metric_codes=metric_codes)

    out = {
        'generated_at': datetime.utcnow().isoformat()+'Z',
        'metrics': {mc: {
            'value': r.value,
            'unit': r.unit,
            'formula_id': r.formula_id,
            'status': r.status,
            'note': r.note,
        } for mc, r in res.items()}
    }

    out_path = (repo_root / args.out).resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding='utf-8')

    print(json.dumps(out, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
