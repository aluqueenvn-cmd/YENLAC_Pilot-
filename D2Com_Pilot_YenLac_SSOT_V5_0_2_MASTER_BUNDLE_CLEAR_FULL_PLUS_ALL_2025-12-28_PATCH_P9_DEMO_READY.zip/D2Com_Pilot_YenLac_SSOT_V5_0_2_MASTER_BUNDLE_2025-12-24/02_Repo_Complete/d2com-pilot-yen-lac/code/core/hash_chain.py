"""hash_chain.py

Tamper-evident append-only helper.
Tạo 'chuỗi băm' (hash chain) song song với event_log, KHÔNG sửa event_log.

English → Việt:
- tamper-evident: chống chỉnh sửa lén
- hash chain: chuỗi băm (mỗi dòng phụ thuộc hash dòng trước)
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Dict, Optional, Tuple


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def compute_chain_hash(prev_hash: str, event_obj: Dict[str, Any]) -> str:
    payload = json.dumps(event_obj, ensure_ascii=False, sort_keys=True).encode("utf-8")
    return sha256_hex((prev_hash + "|" + sha256_hex(payload)).encode("utf-8"))


def read_last_hash(chain_path: Path) -> str:
    if not chain_path.exists():
        return "0" * 64
    last = None
    with chain_path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                last = line
    if not last:
        return "0" * 64
    try:
        obj = json.loads(last)
        return str(obj.get("hash", "0" * 64))
    except Exception:
        return "0" * 64


def append_chain(chain_path: Path, event_obj: Dict[str, Any]) -> Tuple[str, str]:
    chain_path.parent.mkdir(parents=True, exist_ok=True)
    prev_hash = read_last_hash(chain_path)
    h = compute_chain_hash(prev_hash, event_obj)
    entry = {
        "event_log_id": event_obj.get("event_log_id"),
        "ingest_ts": event_obj.get("ingest_ts"),
        "source_batch_id": event_obj.get("source_batch_id"),
        "prev_hash": prev_hash,
        "hash": h,
    }
    with chain_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    return prev_hash, h
