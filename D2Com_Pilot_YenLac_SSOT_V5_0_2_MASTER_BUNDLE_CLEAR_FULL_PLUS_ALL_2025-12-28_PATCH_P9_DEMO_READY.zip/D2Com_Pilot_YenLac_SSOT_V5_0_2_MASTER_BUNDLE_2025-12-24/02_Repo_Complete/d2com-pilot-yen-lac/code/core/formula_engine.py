"""formula_engine.py - Minimal KPI engine that evaluates Formula DSL.

English -> Viet:
- KPI (Key Performance Indicator): chi so do hieu suat
- DSL (Domain-Specific Language): ngon ngu cong thuc chuyen biet
- mapping: anh xa (noi KPI se doc du lieu o dau)

Muc dich (V0):
- Doc registry/formulas.csv
- Doc cot expression_dsl (JSON string)
- Hien tai chi ho tro fn="BOARD_METRICS" de chay demo nhanh

Luu y:
- Day la engine toi gian de khoi dong, chua phai DSL tong quat.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

import pandas as pd
from core.formula_dsl_v1 import eval_dsl_v1


@dataclass
class FormulaEvalResult:
    formula_id: str
    metric_code: str
    value: Any
    unit: str | None = None
    status: str | None = None
    note: str | None = None


def load_formulas(registry_dir: Path) -> pd.DataFrame:
    p = registry_dir / "formulas.csv"
    return pd.read_csv(p, encoding='utf-8-sig')


def eval_formula(repo_root: Path, formula_row: Dict[str, Any], ctx: Optional[Dict[str, Any]] = None) -> FormulaEvalResult:
    """Evaluate a single formula row.

    Supported DSL (V0):
      {"fn":"BOARD_METRICS","key":"consent_rate"}
    """
    formula_id = str(formula_row.get("formula_id") or "").strip()
    metric_code = str(formula_row.get("metric_code") or "").strip()
    unit = str(formula_row.get("unit") or "").strip() or None
    status = str(formula_row.get("status") or "").strip() or None

    dsl_raw = formula_row.get("expression_dsl")
    if not isinstance(dsl_raw, str) or not dsl_raw.strip():
        return FormulaEvalResult(
            formula_id=formula_id,
            metric_code=metric_code,
            unit=unit,
            status=status,
            value=None,
            note="expression_dsl is empty",
        )

    try:
        dsl = json.loads(dsl_raw)
    except Exception as e:
        return FormulaEvalResult(
            formula_id=formula_id,
            metric_code=metric_code,
            unit=unit,
            status=status,
            value=None,
            note=f"bad JSON in expression_dsl: {e}",
        )

    fn = dsl.get("fn")
    if fn == "BOARD_METRICS":
        key = dsl.get("key")
        if not key:
            return FormulaEvalResult(formula_id, metric_code, None, unit, status, "missing key")

        # Import here to avoid hard dependency when running headless
        from ok_computer.utils.board_metrics import compute_board_metrics

        bm = compute_board_metrics(repo_root)
        return FormulaEvalResult(formula_id, metric_code, bm.get(key), unit, status, note="BOARD_METRICS")

    # DSL V1 branch
    if isinstance(dsl, dict) and dsl.get("dsl_version") == "1.0":
        r = eval_dsl_v1(repo_root, dsl, ctx=ctx)
        return FormulaEvalResult(formula_id, metric_code, r.value, unit, status, note=(r.note or 'DSL_V1'))

    return FormulaEvalResult(
        formula_id=formula_id,
        metric_code=metric_code,
        unit=unit,
        status=status,
        value=None,
        note=f"unsupported fn={fn}",
    )


def eval_metrics(repo_root: Path, metric_codes: Optional[set[str]] = None, ctx: Optional[Dict[str, Any]] = None) -> Dict[str, FormulaEvalResult]:
    """Evaluate formulas and return result by metric_code."""
    reg_dir = repo_root / "registry"
    df = load_formulas(reg_dir)

    out: Dict[str, FormulaEvalResult] = {}
    for _, r in df.iterrows():
        mc = str(r.get("metric_code") or "").strip()
        if not mc:
            continue
        if metric_codes is not None and mc not in metric_codes:
            continue
        res = eval_formula(repo_root, r.to_dict(), ctx=ctx)
        out[mc] = res
    return out
