"""formula_dsl_v1.py – Evaluator cho Formula DSL V1 (JSON).

Chỉ implement whitelist ops để demo KPI (DEMO_15) chạy an toàn.

English → Việt:
- evaluator: bộ tính
- whitelist ops: chỉ cho phép tập thao tác cố định (tránh eval code)
- entity: thực thể (job_id/house_id)
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import numpy as np
import pandas as pd

from core.asset_loader import AssetLoader


@dataclass
class DslEvalResult:
    value: Any
    note: str = ""


def _to_dt(s: pd.Series) -> pd.Series:
    return pd.to_datetime(s, errors="coerce", utc=True)


def _get_payload_value(d: Any, key: str) -> Any:
    if isinstance(d, dict):
        return d.get(key)
    return None


def get_field_series(df: pd.DataFrame, field: str) -> pd.Series:
    """Support dot notation: payload.xxx, and canonical aliases."""
    # canonical aliases
    aliases = {
        "event_code_canonical": "event_code",
        "event_at": "event_ts",
        "ingested_at": "ingest_ts",
    }
    f = aliases.get(field, field)

    if f.startswith("payload."):
        k = f.split(".", 1)[1]
        if "_payload_dict" in df.columns:
            return df["_payload_dict"].apply(lambda d: _get_payload_value(d, k))
        if "payload" in df.columns:
            return df["payload"].apply(lambda d: _get_payload_value(d, k))
        return pd.Series([None] * len(df))
    if f in df.columns:
        return df[f]
    # missing -> None series
    return pd.Series([None] * len(df))


def eval_where(df: pd.DataFrame, where: Optional[Dict[str, Any]]) -> pd.Series:
    """Evaluate boolean filter."""
    if not where:
        return pd.Series([True] * len(df))

    op = where.get("op")
    if op == "eq":
        s = get_field_series(df, where["field"])
        return s.astype(object) == where.get("value")
    if op == "in":
        s = get_field_series(df, where["field"])
        vals = where.get("value") or []
        return s.astype(object).isin(list(vals))
    if op == "exists":
        s = get_field_series(df, where["field"])
        return s.notna() & (s.astype(str).str.len() > 0)
    if op == "and":
        masks = [eval_where(df, w) for w in where.get("args", [])]
        if not masks:
            return pd.Series([True] * len(df))
        m = masks[0]
        for x in masks[1:]:
            m = m & x
        return m
    if op == "or":
        masks = [eval_where(df, w) for w in where.get("args", [])]
        if not masks:
            return pd.Series([False] * len(df))
        m = masks[0]
        for x in masks[1:]:
            m = m | x
        return m

    # unknown op -> fail closed (no rows)
    return pd.Series([False] * len(df))


def safe_div(num: float, den: float) -> Tuple[Optional[float], str]:
    if den is None or den == 0:
        return None, "denominator=0"
    try:
        return float(num) / float(den), ""
    except Exception as e:
        return None, f"bad_div:{e}"


def _load_table_df(loader: AssetLoader, table: str) -> Tuple[pd.DataFrame, str]:
    if table == "event_log":
        la = loader.load_event_log_flat()
        return la.df, la.note
    la = loader.load_table(table)
    return la.df, la.note


def _duration_per_entity(
    df_events: pd.DataFrame,
    entity_key: str,
    start_event: str,
    end_event: str,
    start_where: Optional[Dict[str, Any]] = None,
    end_where: Optional[Dict[str, Any]] = None,
) -> pd.Series:
    """Return duration hours between first start_event and first end_event (after start) per entity."""
    if df_events.empty or entity_key not in df_events.columns:
        return pd.Series(dtype=float)

    df = df_events.copy()
    df = df[df[entity_key].notna()]
    if df.empty:
        return pd.Series(dtype=float)

    # normalize dt
    ts = _to_dt(get_field_series(df, "event_at"))
    df["_ts"] = ts

    # start times
    start_df = df[df["event_code_canonical"] == start_event].dropna(subset=["_ts"])
    if start_where:
        smask = eval_where(start_df, start_where)
        start_df = start_df[smask]
    if start_df.empty:
        return pd.Series(dtype=float)
    start_ts = start_df.groupby(entity_key)["_ts"].min()

    # end times with optional filter
    end_df = df[df["event_code_canonical"] == end_event].dropna(subset=["_ts"])
    if end_where:
        mask = eval_where(end_df, end_where)
        end_df = end_df[mask]
    if end_df.empty:
        return pd.Series(dtype=float)

    end_ts = end_df.groupby(entity_key)["_ts"].min()

    # align and compute
    joined = pd.DataFrame({"start": start_ts, "end": end_ts}).dropna()
    # only keep if end >= start
    joined = joined[joined["end"] >= joined["start"]]
    if joined.empty:
        return pd.Series(dtype=float)
    dur_hours = (joined["end"] - joined["start"]).dt.total_seconds() / 3600.0
    dur_hours.name = "duration_hours"
    return dur_hours


def eval_expr(repo_root: Path, loader: AssetLoader, expr: Dict[str, Any], ctx: Optional[Dict[str, Any]] = None) -> DslEvalResult:
    op = expr.get("op")
    source = (expr.get("source") or {})
    # Backward compatible keys:
    # - table can be expr.table or expr.source.table
    # - entity key can be entity_key or entity_field
    table = expr.get("table") or source.get("table") or "event_log"

    # Param reference (for thresholds / scenario-driven formulas)
    if op == "param":
        code = str(expr.get("code") or "").strip()
        params = (ctx or {}).get("params") or {}
        if code in params:
            return DslEvalResult(params.get(code), f"param:{code}")
        # allow alias lookup if provided
        alias = (ctx or {}).get("param_alias") or {}
        if code in alias and alias[code] in params:
            return DslEvalResult(params.get(alias[code]), f"param_alias:{code}->{alias[code]}")
        return DslEvalResult(None, f"param_missing:{code}")

    # duration-based entity ops (no need to load extra tables)
    if op == "rate_entities_duration_lte":
        df, note = _load_table_df(loader, table)
        entity_key = expr.get("entity_key") or expr.get("entity_field")
        if not entity_key:
            return DslEvalResult(None, f"missing_entity_key|{note}")
        start_event = expr["start_event"]
        end_event = expr["end_event"]
        thr = float(expr.get("threshold_hours", 0))
        durs = _duration_per_entity(df, str(entity_key), start_event, end_event, start_where=expr.get("start_where"), end_where=expr.get("end_where"))
        if durs.empty:
            return DslEvalResult(None, f"no_duration_entities|{note}")
        den = len(durs)
        num = int((durs <= thr).sum())
        val, n2 = safe_div(num, den)
        return DslEvalResult(val, ("|".join([x for x in [note, n2] if x]) or ""))

    if op == "rate_entities_without_event":
        df, note = _load_table_df(loader, table)
        entity_key = expr.get("entity_key") or expr.get("entity_field")
        if not entity_key:
            return DslEvalResult(None, f"missing_entity_key|{note}")
        end_event = expr["end_event"]
        bad_event = expr["bad_event"]
        if df.empty or entity_key not in df.columns:
            return DslEvalResult(None, f"empty|{note}")
        # denom: entities with end_event
        end_entities = set(df.loc[df["event_code_canonical"] == end_event, entity_key].dropna().astype(str))
        if not end_entities:
            return DslEvalResult(None, f"no_end_entities|{note}")
        bad_entities = set(df.loc[df["event_code_canonical"] == bad_event, entity_key].dropna().astype(str))
        good = len(end_entities - bad_entities)
        val, n2 = safe_div(good, len(end_entities))
        return DslEvalResult(val, ("|".join([x for x in [note, n2] if x]) or ""))

    if op in ("avg_entities_duration_days_between_events", "avg_entities_duration_hours_between_events"):
        df, note = _load_table_df(loader, table)
        entity_key = expr.get("entity_key") or expr.get("entity_field")
        if not entity_key:
            return DslEvalResult(None, f"missing_entity_key|{note}")
        start_event = expr["start_event"]
        end_event = expr["end_event"]
        durs_h = _duration_per_entity(
            df,
            str(entity_key),
            start_event,
            end_event,
            start_where=expr.get("start_where"),
            end_where=expr.get("end_where"),
        )
        if durs_h.empty:
            return DslEvalResult(None, f"no_duration_entities|{note}")
        if op == "avg_entities_duration_days_between_events":
            val = float((durs_h / 24.0).mean())
        else:
            val = float(durs_h.mean())
        return DslEvalResult(val, note)

    # Basic table aggregations
    df, note = _load_table_df(loader, table)
    if df.empty:
        return DslEvalResult(None, f"empty_table|{note}")

    where = expr.get("where")
    mask = eval_where(df, where)
    df2 = df[mask]

    if op == "count":
        return DslEvalResult(int(len(df2)), note)
    if op == "count_distinct":
        field = expr["field"]
        s = get_field_series(df2, field)
        return DslEvalResult(int(s.dropna().nunique()), note)
    if op == "sum":
        field = expr["field"]
        s = pd.to_numeric(get_field_series(df2, field), errors="coerce")
        return DslEvalResult(float(s.dropna().sum()), note)
    if op == "avg":
        field = expr["field"]
        s = pd.to_numeric(get_field_series(df2, field), errors="coerce")
        if s.dropna().empty:
            return DslEvalResult(None, f"no_numeric|{note}")
        return DslEvalResult(float(s.dropna().mean()), note)
    if op == "ratio":
        num_expr = expr["num"]
        den_expr = expr["den"]
        num_res = eval_expr(repo_root, loader, num_expr, ctx=ctx)
        den_res = eval_expr(repo_root, loader, den_expr, ctx=ctx)
        val, n2 = safe_div(num_res.value, den_res.value)
        note2 = "|".join([x for x in [num_res.note, den_res.note, n2] if x])
        return DslEvalResult(val, note2)

    return DslEvalResult(None, f"unsupported_op:{op}|{note}")


def eval_dsl_v1(repo_root: Path, dsl: Dict[str, Any], loader: Optional[AssetLoader] = None, ctx: Optional[Dict[str, Any]] = None) -> DslEvalResult:
    if dsl.get("dsl_version") != "1.0":
        return DslEvalResult(None, "dsl_version_not_1.0")
    expr = dsl.get("expr")
    if not isinstance(expr, dict):
        return DslEvalResult(None, "missing_expr")
    loader = loader or AssetLoader(repo_root)
    return eval_expr(repo_root, loader, expr, ctx=ctx)
