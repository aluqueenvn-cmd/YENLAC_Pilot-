"""asset_loader.py – Loader cho Data Assets theo registry/data_assets.yaml.

Mục tiêu:
- Registry-first: đường dẫn canonical lấy từ registry/data_assets.yaml.
- Fallback demo_source nếu dữ liệu canonical chưa tồn tại (để demo chạy out-of-box).
- Không phá nguyên tắc append-only: loader chỉ đọc.

English → Việt:
- asset: tài sản dữ liệu (một bảng hoặc nhật ký)
- canonical path: đường dẫn chuẩn (đường dẫn “đúng” trong data/)
- fallback: dự phòng
"""

from __future__ import annotations

import os

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import pandas as pd
import yaml


@dataclass
class LoadedAsset:
    table: str
    path: Path
    df: pd.DataFrame
    note: str = ""


class AssetLoader:
    """Load tables (assets) by table code using registry/data_assets.yaml."""

    def __init__(self, repo_root: Path):
        self.repo_root = repo_root
        # Override data root for demo/ops via env var.
        # D2COM_STORE_ROOT should point to a folder that contains a "data/" subtree.
        self.asset_root = Path(os.environ.get("D2COM_STORE_ROOT", str(repo_root))).resolve()
        self._cache: Dict[str, LoadedAsset] = {}
        self._assets = self._load_registry()

    def _load_registry(self) -> Dict[str, Dict[str, Any]]:
        reg_path = self.repo_root / "registry" / "data_assets.yaml"
        obj = yaml.safe_load(reg_path.read_text(encoding="utf-8"))
        out: Dict[str, Dict[str, Any]] = {}
        for a in obj.get("assets", []) or []:
            code = a.get("asset_code")
            if code:
                out[str(code)] = a
        return out

    def _resolve_path(self, asset: Dict[str, Any]) -> Tuple[Path, str]:
        """Return (path, note). Prefer canonical; fallback to demo_source."""
        candidates = []
        if asset.get("default_path"):
            candidates.append(self.asset_root / str(asset["default_path"]))
        if asset.get("expected_canonical_path"):
            candidates.append(self.asset_root / str(asset["expected_canonical_path"]))

        for p in candidates:
            if p.exists():
                return p, "canonical"

        demo = asset.get("demo_source")
        if demo:
            p = self.repo_root / str(demo)
            if p.exists():
                return p, "demo_source"

        # If nothing exists, still return a canonical-ish path for messaging
        if candidates:
            return candidates[0], "missing"
        if demo:
            return self.repo_root / str(demo), "missing"
        return self.asset_root / "data" / f"{asset.get('asset_code','unknown')}", "missing"

    def load_table(self, table: str) -> LoadedAsset:
        if table in self._cache:
            return self._cache[table]

        asset = self._assets.get(table)
        if not asset:
            la = LoadedAsset(table=table, path=Path(""), df=pd.DataFrame(), note="unknown_table")
            self._cache[table] = la
            return la

        path, mode = self._resolve_path(asset)
        typ = (asset.get("type") or "").lower()

        if not path.exists():
            la = LoadedAsset(table=table, path=path, df=pd.DataFrame(), note=f"{mode}:file_not_found")
            self._cache[table] = la
            return la

        try:
            # Special-case: event_log demo_source dùng CSV nhưng asset type vẫn jsonl
            if typ == "jsonl" and path.suffix.lower() == ".csv":
                df = pd.read_csv(path, encoding='utf-8-sig')
            elif typ == "csv":
                df = pd.read_csv(path, encoding='utf-8-sig')
            elif typ == "jsonl":
                rows = []
                with path.open("r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            rows.append(json.loads(line))
                        except Exception:
                            continue
                df = pd.DataFrame(rows)
            else:
                # fallback attempt
                if path.suffix.lower() == ".csv":
                    df = pd.read_csv(path, encoding='utf-8-sig')
                else:
                    rows = []
                    with path.open("r", encoding="utf-8") as f:
                        for line in f:
                            line = line.strip()
                            if line:
                                try:
                                    rows.append(json.loads(line))
                                except Exception:
                                    pass
                    df = pd.DataFrame(rows)

            la = LoadedAsset(table=table, path=path, df=df, note=mode)
        except Exception as e:
            la = LoadedAsset(table=table, path=path, df=pd.DataFrame(), note=f"load_error:{e}")

        self._cache[table] = la
        return la

    def load_event_log_flat(self) -> LoadedAsset:
        """Flatten event_log payload -> columns for easier DSL filtering.

        Supports 2 inputs:
        - canonical jsonl produced by ingest_pipeline (with `payload` dict)
        - demo csv (events_demo.csv) with `payload_json` string
        """
        la = self.load_table("event_log")
        df = la.df.copy()
        if df.empty:
            return la

        # Normalize from demo CSV (payload_json -> payload dict)
        if "payload_json" in df.columns and "payload" not in df.columns:
            def _parse(x):
                if isinstance(x, str) and x.strip():
                    try:
                        return json.loads(x)
                    except Exception:
                        return {}
                return {}
            df["payload"] = df["payload_json"].apply(_parse)

        # Ensure canonical-ish column names exist
        # demo csv has event_ts; ingest jsonl has event_ts too; keep as is.
        if "event_code" in df.columns and "event_code_canonical" not in df.columns:
            df["event_code_canonical"] = df["event_code"]

        # Build _payload_dict for dot-field reads
        if "payload" in df.columns:
            def _as_dict(x):
                return x if isinstance(x, dict) else {}
            df["_payload_dict"] = df["payload"].apply(_as_dict)

            # lift common IDs
            for k in ("house_id", "job_id", "actor_id", "lead_id", "consent_id", "consent_flag"):
                if k not in df.columns:
                    df[k] = df["_payload_dict"].apply(lambda d: d.get(k))

        la2 = LoadedAsset(table=la.table, path=la.path, df=df, note=la.note)
        self._cache["event_log_flat"] = la2
        return la2
