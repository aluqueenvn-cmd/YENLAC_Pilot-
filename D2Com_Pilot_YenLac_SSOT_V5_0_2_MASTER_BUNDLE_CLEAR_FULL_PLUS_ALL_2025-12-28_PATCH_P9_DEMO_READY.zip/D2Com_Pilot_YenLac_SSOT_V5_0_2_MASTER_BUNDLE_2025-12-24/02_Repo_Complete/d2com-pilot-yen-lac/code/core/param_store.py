"""
param_store.py — Load Param Master Excel into a typed param dictionary.

English → Việt:
- Param Master: bảng tham số (nguồn SSOT cho giả lập)
- adapter: bộ chuyển (Excel → app)
- override: ghi đè (theo scenario)

Nguyên tắc:
- Không bịa: nếu Excel thiếu param_code thì trả None + note rõ.
- Append-only: module này chỉ đọc.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import pandas as pd
import yaml


@dataclass(frozen=True)
class ParamDef:
    group: str
    code: str
    name_vi_en: str
    unit: str
    data_type: str
    input_type: str
    allowed_values: str
    default: Optional[float]
    min_value: Optional[float]
    max_value: Optional[float]
    step: Optional[float]
    impact: str
    example: str
    evidence_note: str


def _read_param_master_excel(path: Path) -> pd.DataFrame:
    df = pd.read_excel(path, sheet_name="Param_Master", header=2)
    # normalize columns
    df = df.rename(columns={c: str(c).strip() for c in df.columns})
    df = df[df.get("Param_Code").notna()].copy()
    df["Param_Code"] = df["Param_Code"].astype(str).str.strip()
    return df


def _to_float(x: Any) -> Optional[float]:
    try:
        if x is None or (isinstance(x, float) and pd.isna(x)):
            return None
        if isinstance(x, str) and x.strip() == "":
            return None
        return float(x)
    except Exception:
        return None


def load_param_alias(registry_dir: Path) -> Dict[str, str]:
    p = registry_dir / "param_alias.yaml"
    if not p.exists():
        return {}
    obj = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    aliases = obj.get("aliases") or {}
    out: Dict[str, str] = {}
    for k, v in aliases.items():
        if k and v:
            out[str(k).strip()] = str(v).strip()
    return out


def load_param_defs(
    repo_root: Path,
    primary_excel: Path,
    addon_excels: Optional[List[Path]] = None,
) -> Tuple[List[ParamDef], Dict[str, str]]:
    """Return param definitions + alias mapping."""
    registry_dir = repo_root / "registry"
    alias = load_param_alias(registry_dir)

    df = _read_param_master_excel(primary_excel)
    if addon_excels:
        for p in addon_excels:
            if p.exists():
                df2 = _read_param_master_excel(p)
                df = pd.concat([df, df2], ignore_index=True)

    # de-dup by Param_Code (last wins)
    df = df.drop_duplicates(subset=["Param_Code"], keep="last")

    defs: List[ParamDef] = []
    for _, r in df.iterrows():
        defs.append(
            ParamDef(
                group=str(r.get("Nhóm") or "").strip(),
                code=str(r.get("Param_Code") or "").strip(),
                name_vi_en=str(r.get("Tên (VI + EN)") or r.get("Tên (VI+EN)") or "").strip(),
                unit=str(r.get("Đơn vị (Unit)") or r.get("Đơn vị") or "").strip(),
                data_type=str(r.get("Data_Type") or "").strip(),
                input_type=str(r.get("Input_Type") or "").strip(),
                allowed_values=str(r.get("Allowed_Values") or "").strip(),
                default=_to_float(r.get("Default")),
                min_value=_to_float(r.get("Min")),
                max_value=_to_float(r.get("Max")),
                step=_to_float(r.get("Step")),
                impact=str(r.get("Tác động (K-level / State)") or r.get("Tác động (K/State)") or "").strip(),
                example=str(r.get("Ví dụ dễ hiểu") or r.get("Ví dụ") or "").strip(),
                evidence_note=str(r.get("Evidence/Note") or "").strip(),
            )
        )
    return defs, alias


def build_default_param_values(param_defs: Iterable[ParamDef]) -> Dict[str, Optional[float]]:
    out: Dict[str, Optional[float]] = {}
    for p in param_defs:
        out[p.code] = p.default
    return out


def normalize_param_code(code: str, alias: Dict[str, str]) -> str:
    c = str(code or "").strip()
    return alias.get(c, c)


def apply_overrides(
    base: Dict[str, Optional[float]],
    overrides: Dict[str, Any],
    alias: Optional[Dict[str, str]] = None,
) -> Dict[str, Optional[float]]:
    alias = alias or {}
    out = dict(base)
    for k, v in (overrides or {}).items():
        ck = normalize_param_code(str(k), alias)
        out[ck] = _to_float(v)
    return out
