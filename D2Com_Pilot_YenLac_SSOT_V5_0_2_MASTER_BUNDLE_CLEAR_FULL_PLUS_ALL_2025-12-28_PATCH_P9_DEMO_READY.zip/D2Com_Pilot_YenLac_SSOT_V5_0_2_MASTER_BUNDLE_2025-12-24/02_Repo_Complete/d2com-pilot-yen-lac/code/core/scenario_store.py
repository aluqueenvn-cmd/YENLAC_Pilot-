"""
scenario_store.py — Load Scenario Library Excel and expose scenarios as dict.

English → Việt:
- scenario: kịch bản (tập giả định)
- scenario overrides: giá trị ghi đè theo param_code
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd
import re


@dataclass(frozen=True)
class Scenario:
    scenario_id: str
    title: str
    overrides: Dict[str, Any]
    missing_params: List[str]


def _read_scenario_excel(path: Path) -> pd.DataFrame:
    df = pd.read_excel(path, sheet_name="Scenario_Library", header=18)
    df = df.rename(columns={c: str(c).strip() for c in df.columns})
    df = df[df.get("Param_Code").notna()].copy()
    df["Param_Code"] = df["Param_Code"].astype(str).str.strip()
    return df


def load_scenarios_from_excel(path: Path) -> Dict[str, Scenario]:
    df = _read_scenario_excel(path)

    scenario_cols = [c for c in df.columns if re.match(r"^(BASE|BEST|WORST|S\d{2})$", str(c))]
    # fallback: some files include S01..S10 as strings
    if not scenario_cols:
        scenario_cols = [c for c in df.columns if str(c).upper() in {"BASE","BEST","WORST"} or str(c).startswith("S")]

    out: Dict[str, Scenario] = {}
    for sid in scenario_cols:
        overrides: Dict[str, Any] = {}
        missing: List[str] = []
        for _, r in df.iterrows():
            pc = str(r.get("Param_Code") or "").strip()
            if not pc:
                continue
            val = r.get(sid)
            miss_flag = r.get("Missing?")
            if isinstance(miss_flag, str) and miss_flag.strip():
                # if missing flag filled, treat as missing for all scenarios
                missing.append(pc)
                continue
            overrides[pc] = val
        out[str(sid)] = Scenario(
            scenario_id=str(sid),
            title=str(sid),
            overrides=overrides,
            missing_params=sorted(set(missing)),
        )
    return out
