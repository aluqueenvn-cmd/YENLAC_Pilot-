"""alerting.py – Alert router (định tuyến cảnh báo) cho demo.

Mục tiêu:
- Mặc định ghi ra JSONL file (không phụ thuộc internet).
- Nếu có cấu hình WEBHOOK_URL thì gửi thêm HTTP POST.

English → Việt:
- webhook: URL nhận thông báo tự động
- route: tuyến/đường đi
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional
import urllib.request

import yaml


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def append_jsonl(path: Path, obj: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")


def load_routes(repo_root: Path) -> Dict[str, Any]:
    p = repo_root / "registry" / "alert_routes.yaml"
    if not p.exists():
        return {}
    return yaml.safe_load(p.read_text(encoding="utf-8")) or {}


def send_webhook(url: str, payload: Dict[str, Any], timeout_sec: int = 5) -> None:
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    urllib.request.urlopen(req, timeout=timeout_sec).read()


def emit_alert(
    repo_root: Path,
    route_name: str,
    payload: Dict[str, Any],
    *,
    allow_webhook: bool = True,
) -> None:
    """Emit alert theo route.

    route_name thường dùng: default, kill_switch, ops_sla.
    """
    routes = load_routes(repo_root).get("routes", {}) or {}
    route = routes.get(route_name) or routes.get("default") or {}

    enriched = {
        "ts": utc_now_iso(),
        "route": route_name,
        **payload,
    }

    # 1) file channel (default)
    if route.get("channel") == "file":
        target = str(route.get("target") or "data/audit/alerts.jsonl")
        append_jsonl(repo_root / target, enriched)

    # 2) optional webhook
    if allow_webhook:
        url = os.getenv("ALERT_WEBHOOK_URL", "").strip()
        if url:
            try:
                send_webhook(url, enriched)
            except Exception:
                # Demo mode: ignore network errors
                pass
