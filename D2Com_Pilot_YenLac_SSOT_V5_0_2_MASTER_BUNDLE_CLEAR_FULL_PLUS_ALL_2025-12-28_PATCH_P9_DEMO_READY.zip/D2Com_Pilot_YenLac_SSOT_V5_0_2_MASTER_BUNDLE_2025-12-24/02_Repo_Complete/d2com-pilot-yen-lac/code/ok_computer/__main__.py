# Allows: python -m code.ok_computer (optional)
from .app import *  # noqa
