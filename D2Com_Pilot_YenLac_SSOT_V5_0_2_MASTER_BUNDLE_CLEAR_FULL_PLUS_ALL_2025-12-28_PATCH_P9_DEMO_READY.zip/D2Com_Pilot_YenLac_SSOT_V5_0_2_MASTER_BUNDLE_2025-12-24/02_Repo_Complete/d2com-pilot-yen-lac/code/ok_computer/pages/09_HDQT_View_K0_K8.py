"""
HDQT View (V5.0.2) — 1-minute dashboard (K0–K8) using Formula Engine.

English → Việt:
- Board view: màn HĐQT (tổng quan 1 phút)
- drilldown: bấm sâu xem chi tiết
- threshold: ngưỡng cảnh báo / siết / dừng
"""

import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

import pandas as pd
import streamlit as st
import yaml

from registry_loader import load_registries, repo_root_from_here
from utils.glossary_utils import term_tooltip
from utils.threshold_eval import evaluate_metric
from state import ensure_params_loaded, ensure_data_source
from core.formula_engine import eval_metrics
from core.asset_loader import AssetLoader


st.set_page_config(page_title="HDQT View K0–K8", layout="wide", initial_sidebar_state="expanded")

repo_root = repo_root_from_here()
regs = load_registries(repo_root)
ensure_params_loaded(repo_root)
ensure_data_source(repo_root)

metrics_df = regs["metrics"]
formulas_df = regs["formulas"]
thresholds = regs.get("thresholds") or {}

st.title("🏛️ HĐQT View (K0–K8) — 1 phút nhìn là hiểu")
st.caption("Nguồn KPI: Formula Engine + demo_inputs (giả lập). Append-only dữ liệu.")


# -----------------------------
# Load param values for threshold linking
# -----------------------------
params = st.session_state.get("param_values") or {}
param_alias = st.session_state.get("param_alias") or {}

ctx = {"params": params, "param_alias": param_alias}

ready_codes = sorted(set(formulas_df.loc[formulas_df["status"] == "READY_DEMO", "metric_code"].astype(str)))
if not ready_codes:
    st.warning("Chưa có KPI READY_DEMO.")
    st.stop()

# Allow user to pick KPI set
with st.sidebar:
    st.subheader("KPI set")
    picked = st.multiselect("READY_DEMO metrics", options=ready_codes, default=ready_codes)
    show_drilldown = st.checkbox("Show drilldown tables", value=True)

results = eval_metrics(repo_root, metric_codes=set(picked), ctx=ctx)

# -----------------------------
# Choose headline per K-level
# -----------------------------
k_levels = [f"K{i}" for i in range(0, 9)]
headline_by_k: Dict[str, str] = {}

# preferred ordering: within each K, prefer kill_switch metrics first
for k in k_levels:
    subset = metrics_df[(metrics_df["k_level"] == k) & (metrics_df["metric_code"].isin(results.keys()))].copy()
    if subset.empty:
        headline_by_k[k] = ""
        continue
    subset["kill_switch"] = subset["kill_switch"].astype(str).str.lower().isin(["true", "1", "yes"])
    subset = subset.sort_values(by=["kill_switch", "metric_code"], ascending=[False, True])
    headline_by_k[k] = str(subset.iloc[0]["metric_code"])

# -----------------------------
# Render tiles (3x3)
# -----------------------------
def _fmt_value(v: Any, unit: str) -> str:
    if v is None:
        return "N/A"
    try:
        fv = float(v)
    except Exception:
        return str(v)
    if unit == "vnd":
        return f"{fv:,.0f} đ"
    if unit == "rate":
        return f"{fv:.2%}"
    if unit == "hours":
        return f"{fv:.1f} h"
    if unit == "count":
        return f"{fv:,.0f}"
    return f"{fv:.2f}"


def _metric_row(metric_code: str) -> Optional[pd.Series]:
    m = metrics_df[metrics_df["metric_code"] == metric_code]
    return m.iloc[0] if not m.empty else None


def _color_emoji(color: str) -> str:
    if color == "GREEN":
        return "🟢"
    if color == "AMBER":
        return "🟠"
    if color == "RED":
        return "🔴"
    return "⚪"


rows = [k_levels[0:3], k_levels[3:6], k_levels[6:9]]
for row in rows:
    cols = st.columns(3)
    for col, k in zip(cols, row):
        with col:
            mc = headline_by_k.get(k) or ""
            st.subheader(k)
            if not mc:
                st.info("N/A (chưa có DSL/metric trong set)")
                continue
            mr = _metric_row(mc)
            unit = str(mr["unit"]) if mr is not None else ""
            name_vi = str(mr["metric_name_vi"]) if mr is not None else mc
            val = results[mc].value if mc in results else None

            color, tier = evaluate_metric(repo_root, mc, val, params=params)
            st.markdown(f"**{_color_emoji(color)} {term_tooltip(mc, fallback=name_vi)}**")
            st.metric(label=mc, value=_fmt_value(val, unit))
            st.caption(f"Tier: {tier} | Note: {results[mc].note}")

            if show_drilldown:
                with st.expander("Drilldown", expanded=False):
                    # Show formula DSL
                    fr = formulas_df[formulas_df["metric_code"] == mc]
                    if not fr.empty:
                        st.code(fr.iloc[0]["expression_dsl"], language="json")
                    # Show threshold spec if exists
                    th = regs.get("thresholds") or {}
                    # thresholds.yaml is loaded as dict; show filtered list
                    spec = None
                    for t in (th.get("thresholds") or []):
                        if t.get("metric_code") == mc:
                            spec = t
                            break
                    if spec:
                        st.json(spec)
                    else:
                        st.info("No threshold rule for this metric.")

                    # Show sample events if event_log exists
                    try:
                        loader = AssetLoader(repo_root)
                        la = loader.load_table("event_log")
                        df = la.df
                        if df is None or df.empty:
                            st.info(f"event_log empty ({la.note})")
                        else:
                            # heuristic: filter by event_code if present in DSL
                            codes: Set[str] = set()
                            try:
                                dsl = json.loads(fr.iloc[0]["expression_dsl"])
                                def _walk(x):
                                    if isinstance(x, dict):
                                        if "event_code_in" in x:
                                            for c in (x.get("event_code_in") or []):
                                                codes.add(str(c))
                                        for v in x.values():
                                            _walk(v)
                                    elif isinstance(x, list):
                                        for v in x:
                                            _walk(v)
                                _walk(dsl)
                            except Exception:
                                pass
                            if codes and "event_code_canonical" in df.columns:
                                dff = df[df["event_code_canonical"].isin(list(codes))].sort_values("event_ts", ascending=False).head(50)
                                st.caption(f"Sample events for {len(codes)} codes: {', '.join(list(codes)[:6])}" + (" ..." if len(codes) > 6 else ""))
                                st.dataframe(dff, use_container_width=True)
                            else:
                                st.dataframe(df.sort_values("event_ts", ascending=False).head(30), use_container_width=True)
                    except Exception as e:
                        st.info(f"Drilldown loader unavailable: {e}")
