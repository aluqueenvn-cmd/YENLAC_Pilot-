import time
from pathlib import Path

import pandas as pd
import streamlit as st

from audit_store import append_jsonl, read_jsonl
from registry_loader import load_registries

from utils.glossary_utils import term_label, term_tooltip

st.set_page_config(page_title="Kill-switch (Cầu dao ngắt)", layout="wide")
st.title("🧨 Kill-switch (Cầu dao ngắt)")
st.caption("Khi vượt ngưỡng rủi ro: hệ thống sẽ cảnh báo/siết/ngắt theo tier. Đây là trang mô phỏng + đọc ngưỡng từ SSOT.")

regs = load_registries()
repo_root = Path(regs["repo_root"])
thresholds = regs["thresholds"] or {}
metrics: pd.DataFrame = regs["metrics"]
log_path = repo_root / "audit" / "kill_switch_log.jsonl"

# pick kill-switch metrics from metrics.csv (kill_switch == True)
if "kill_switch" in metrics.columns:
    ks_df = metrics[metrics["kill_switch"].astype(str).str.lower() == "true"]["metric_code"].astype(str).tolist()
else:
    ks_df = []

st.markdown("### 🔥 Nhóm rủi ro Consent/PII (phải đọc kỹ)")
st.info(
    "- "
    f"{term_label('unconsented_pii_risk')}: {term_tooltip('unconsented_pii_risk')}\n"
    f"- {term_label('pending_consent_aging_hours', fallback='Pending consent aging (giờ)')}: Thời gian treo chờ consent; quá ngưỡng phải xin lại hoặc xóa PII."
)

st.caption(f"Danh sách metric có kill-switch (từ metrics.csv): {len(ks_df)}")
metric_code = st.selectbox("Chọn metric_code", ks_df if ks_df else metrics["metric_code"].astype(str).tolist())
st.caption(term_tooltip(metric_code))
value = st.number_input("Giá trị (giả lập)", value=0.0)

action_tier = st.selectbox("Mức phản ứng (action_tier)", [1, 2, 3], index=2)
notes = st.text_area("Ghi chú")

col1, col2 = st.columns(2)
with col1:
    if st.button("TRIGGER (log only)", type="primary"):
        rec = {
            "ts_epoch": int(time.time()),
            "metric_code": metric_code,
            "value": value,
            "action_tier": action_tier,
            "notes": notes,
            "mode": "SIMULATION",
        }
        append_jsonl(log_path, rec)
        st.success("Đã ghi kill-switch log (simulation).")

with col2:
    st.write("Xem ngưỡng (Threshold preview)")
    rules = [r for r in (thresholds.get("thresholds", []) or []) if r.get("metric_code") == metric_code]
    st.json(rules[0] if rules else {})

st.divider()

st.subheader("Nhật ký kill-switch gần đây")
records = read_jsonl(log_path)
if records:
    df = pd.DataFrame(records)
    st.dataframe(df.sort_values(by=df.columns[0], ascending=False), use_container_width=True)
else:
    st.info("Chưa có log.")
