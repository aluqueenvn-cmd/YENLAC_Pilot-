"""
Model Lab (V5.0.2) — Param Master Editor + quick what-if derived outputs.

English → Việt:
- what-if simulation: mô phỏng giả định "nếu...thì..."
- parameter: tham số
- scenario: kịch bản (ghi đè tham số)

Lưu ý:
- Đây là mô hình giả định phục vụ demo. Không phải số liệu thực tế.
- Append-only: mọi export đều ghi thêm file mới, không sửa file cũ.
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import streamlit as st

from state import ensure_params_loaded, ensure_scenarios_loaded, apply_scenario, get_repo_root
from core.param_store import ParamDef, apply_overrides, load_param_defs, build_default_param_values


st.set_page_config(page_title="Model Lab", layout="wide", initial_sidebar_state="expanded")
st.title("🧪 Model Lab: Param Master & Scenario Control")
st.caption("Demo what-if | Mô phỏng giả định. Không dùng như số liệu thật.")


repo_root = get_repo_root()

ensure_params_loaded(repo_root)
ensure_scenarios_loaded(repo_root)

param_defs: List[ParamDef] = st.session_state.get("param_defs") or []
param_values: Dict[str, Any] = st.session_state.get("param_values") or {}
active_scenario = st.session_state.get("active_scenario")

colA, colB = st.columns([2, 1])
with colA:
    st.subheader("Param Master (Excel → App)")
    src = st.session_state.get("param_sources") or {}
    st.caption(f"Nguồn mặc định: {src.get('primary') or 'N/A'}")

with colB:
    st.subheader("Scenario")
    scen = st.session_state.get("scenarios") or {}
    scen_ids = list(scen.keys())
    pick = st.selectbox("Chọn kịch bản (Scenario ID)", ["(none)"] + scen_ids, index=(scen_ids.index(active_scenario)+1 if active_scenario in scen_ids else 0))
    if pick != "(none)":
        if st.button("Apply scenario → Param values", use_container_width=True):
            apply_scenario(pick)
            st.success(f"Applied: {pick}")
            st.rerun()
    else:
        if st.button("Clear active scenario", use_container_width=True):
            st.session_state.pop("active_scenario", None)
            st.success("Cleared.")
            st.rerun()

st.divider()

with st.expander("📥 Tải Param Master Excel khác (optional)", expanded=False):
    up = st.file_uploader("Upload Param Master .xlsx (sheet Param_Master)", type=["xlsx"])
    if up is not None:
        tmp = repo_root / "data" / "uploads" / f"param_master_upload_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        tmp.parent.mkdir(parents=True, exist_ok=True)
        tmp.write_bytes(up.getvalue())
        defs, alias = load_param_defs(repo_root, primary_excel=tmp, addon_excels=[])
        base = build_default_param_values(defs)
        st.session_state["param_defs"] = defs
        st.session_state["param_alias"] = alias
        st.session_state["param_values"] = base
        st.session_state["param_sources"] = {"primary": str(tmp), "addons": []}
        st.success("Loaded uploaded Param Master. (Append-only copy saved)")
        st.rerun()

st.subheader("Chỉnh tham số (grouped)")
q = st.text_input("Search Param_Code / name", value="")
groups = sorted({p.group for p in param_defs if p.group})
pick_groups = st.multiselect("Filter groups", options=groups, default=groups[:6] if len(groups) > 6 else groups)

# Build filtered list
def _match(p: ParamDef) -> bool:
    if pick_groups and p.group and p.group not in pick_groups:
        return False
    if not q:
        return True
    qq = q.lower()
    return (qq in p.code.lower()) or (qq in (p.name_vi_en or "").lower())

filtered = [p for p in param_defs if _match(p)]
st.caption(f"Hiển thị {len(filtered)}/{len(param_defs)} tham số")

# Render grouped editors
by_group: Dict[str, List[ParamDef]] = {}
for p in filtered:
    by_group.setdefault(p.group or "UNGROUPED", []).append(p)

for g in sorted(by_group.keys()):
    with st.expander(g, expanded=False):
        for p in by_group[g]:
            key = f"param::{p.code}"
            cur = param_values.get(p.code, p.default)
            help_txt = f"{p.name_vi_en}\n\nUnit: {p.unit or '-'} | Impact: {p.impact or '-'}\n\nVí dụ: {p.example or '-'}"
            if (p.input_type or "").lower() == "select" and p.allowed_values:
                opts = [x.strip() for x in str(p.allowed_values).split("|") if x.strip()]
                if not opts:
                    opts = [str(cur)]
                val = st.selectbox(p.code, options=opts, index=(opts.index(str(cur)) if str(cur) in opts else 0), help=help_txt, key=key)
                st.session_state["param_values"][p.code] = val
            elif (p.input_type or "").lower() == "slider" and p.min_value is not None and p.max_value is not None:
                step = p.step if p.step is not None else 0.01
                val = st.slider(p.code, min_value=float(p.min_value), max_value=float(p.max_value), value=float(cur if cur is not None else p.default or p.min_value), step=float(step), help=help_txt, key=key)
                st.session_state["param_values"][p.code] = val
            else:
                val = st.number_input(p.code, value=float(cur) if cur is not None else 0.0, help=help_txt, key=key)
                st.session_state["param_values"][p.code] = val

st.divider()
st.subheader("Quick derived outputs (deterministic from params)")
pv = st.session_state.get("param_values") or {}

def _num(code: str) -> Optional[float]:
    v = pv.get(code)
    try:
        return float(v)
    except Exception:
        return None

total_houses = _num("TOTAL_HOUSES_IN_SCOPE")
coverage = _num("DATA_COVERAGE_TARGET")
target_golden_m = _num("TARGET_GOLDEN_PER_MONTH")
working_days = _num("WORKING_DAYS_PER_MONTH")

c1, c2, c3 = st.columns(3)
with c1:
    if total_houses is not None and coverage is not None:
        st.metric("Shadow House_ID target (ước tính)", f"{int(total_houses*coverage):,}")
    else:
        st.metric("Shadow House_ID target (ước tính)", "N/A")

with c2:
    if target_golden_m is not None and working_days not in (None, 0):
        st.metric("Golden/day để đạt target", f"{(target_golden_m/working_days):.2f}")
    else:
        st.metric("Golden/day để đạt target", "N/A")

with c3:
    st.metric("Active scenario", active_scenario or "None")

st.divider()
st.subheader("Export current param values (append-only)")
if st.button("Export → JSON", use_container_width=True):
    out_dir = repo_root / "data" / "append_only" / "params"
    out_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_path = out_dir / f"param_values_{ts}.json"
    out = {
        "meta": {
            "generated_at": datetime.utcnow().isoformat() + "Z",
            "timezone": "Asia/Bangkok",
            "active_scenario": active_scenario,
            "sources": st.session_state.get("param_sources"),
        },
        "params": st.session_state.get("param_values"),
    }
    out_path.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    st.success(f"Saved: {out_path}")
