import streamlit as st

st.set_page_config(page_title="User Guide (Hướng dẫn)", layout="wide")

st.title("📘 Hướng dẫn dùng APP (cho HĐQT + người làm thực địa)")

st.markdown(
    """
## 1) APP này là gì?
Đây là bảng điều khiển demo của Pilot Yên Lạc. Nó được thiết kế theo tư duy:
- **Data-first**: lấy **House_ID state machine (máy trạng thái House_ID)** làm KPI lõi.
- **Append-only**: log chỉ **thêm**, không được sửa lịch sử.
- **Kill-switch (cầu dao ngắt)**: chạm ngưỡng rủi ro (đặc biệt **consent-risk**) là hệ thống cảnh báo/siết/dừng.

## 2) Tao là Chủ tịch HĐQT không rành công nghệ, cần nhìn gì mỗi ngày?
- Vào **09_HĐQT View K0-K8**:
  - Nhìn **đếm nhà theo trạng thái** (SHADOW → QUALIFIED → CLAIMED → FINANCIAL → GOLDEN)
  - Nhìn **Pending consent aging (Giờ treo chờ đồng ý)**
  - Nhìn **Quarantine (hàng bị chặn)** và **Unconsented PII risk (rủi ro PII chưa consent)**
  - Nhìn **SLA lead→survey P90** (90% lead đến khảo sát trong bao lâu)

## 3) Cách đọc màu (traffic-light)
- **GREEN (Xanh)**: ổn, chạy tiếp.
- **AMBER (Vàng)**: đang xấu dần, phải soi nguyên nhân.
- **RED (Đỏ)**: chạm tier dừng/siết, phải họp War-room.

## 4) Khi thấy số xấu, bấm đâu để soi?
- **04_Kill-switch panel**: xem ngưỡng & log “cầu dao”.
- **03_Quarantine queue**: xem record nào bị chặn (sai schema, thiếu bằng chứng, vi phạm consent).
- **02_Gate monitor**: xem cổng kiểm soát (gate) có pass hay fail.
- **00_Glossary**: tra nghĩa thuật ngữ, KPI code, event code (song ngữ).

## 5) Từ điển thuật ngữ (Glossary) là bắt buộc
Nguyên tắc: **tất cả thuật ngữ tiếng Anh phải có tiếng Việt đi kèm**.
Nếu thấy trang nào dùng nhiều chữ Anh khó hiểu: quay lại **00_Glossary** để tra ngay.

## 6) Checklist vận hành (dành cho Field Runner)
- Mỗi sáng: mở **Gate monitor** → nếu fail thì xử trước.
- Xem **Quarantine** → xử dứt điểm theo nhóm lỗi (schema, evidence, consent).
- Xem **HĐQT View** → nếu pending consent >48h: đẩy UST/CTV xin consent hoặc xoá dữ liệu nhạy cảm.

"""
)

st.info("Tip: nếu mày muốn tao viết thêm guide dạng 'phim' (telling story) theo ngôn ngữ Yên Lạc, tao làm được ngay trong docs/user_guide.")
