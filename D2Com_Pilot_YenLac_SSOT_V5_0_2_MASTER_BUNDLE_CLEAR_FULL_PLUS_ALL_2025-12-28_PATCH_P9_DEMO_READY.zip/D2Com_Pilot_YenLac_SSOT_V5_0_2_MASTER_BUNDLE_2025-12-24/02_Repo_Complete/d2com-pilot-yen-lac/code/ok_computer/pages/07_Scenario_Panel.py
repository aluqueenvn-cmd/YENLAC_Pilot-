"""
Scenario Panel (V5.0.2) — Scenario Library Excel → Apply → Run demo metrics.

English → Việt:
- scenario: kịch bản (ghi đè tham số)
- run: chạy giả lập
- append-only log: nhật ký chỉ ghi thêm

Lưu ý:
- Đây là demo. Dữ liệu dùng demo_inputs (giả lập).
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict

import streamlit as st

from audit_store import append_jsonl, read_jsonl
from registry_loader import repo_root_from_here, load_registries
from state import ensure_params_loaded, ensure_scenarios_loaded, apply_scenario
from core.formula_engine import eval_metrics


st.set_page_config(page_title="Scenario Panel", layout="wide", initial_sidebar_state="expanded")

repo_root = repo_root_from_here()
regs = load_registries(repo_root)

ensure_params_loaded(repo_root)
ensure_scenarios_loaded(repo_root)

st.title("🎛️ Scenario Panel: Excel Scenario Library → Demo Run")
st.caption("Chạy demo KPI từ dữ liệu giả lập. Append-only log.")


scenarios = st.session_state.get("scenarios") or {}
scenario_ids = list(scenarios.keys())
active = st.session_state.get("active_scenario")

left, right = st.columns([2, 1])

with left:
    st.subheader("Chọn kịch bản")
    pick = st.selectbox("Scenario ID", ["(none)"] + scenario_ids, index=(scenario_ids.index(active)+1 if active in scenario_ids else 0))
    if pick != "(none)":
        sc = scenarios.get(pick)
        if sc and sc.missing_params:
            st.warning(f"Scenario có tham số thiếu (đánh dấu Missing?): {', '.join(sc.missing_params[:12])}" + (" ..." if len(sc.missing_params) > 12 else ""))
        c1, c2 = st.columns(2)
        with c1:
            if st.button("Apply scenario", use_container_width=True):
                apply_scenario(pick)
                st.success(f"Applied: {pick}")
                st.rerun()
        with c2:
            if st.button("Export scenario JSON", use_container_width=True):
                out_dir = repo_root / "data" / "append_only" / "scenarios"
                out_dir.mkdir(parents=True, exist_ok=True)
                ts = datetime.now().strftime("%Y%m%d_%H%M%S")
                out_path = out_dir / f"scenario_{pick}_{ts}.json"
                payload = {
                    "meta": {
                        "scenario_id": pick,
                        "generated_at": datetime.utcnow().isoformat() + "Z",
                        "source_excel": st.session_state.get("scenario_source"),
                    },
                    "overrides": sc.overrides if sc else {},
                    "missing_params": sc.missing_params if sc else [],
                }
                out_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
                st.success(f"Saved: {out_path}")

with right:
    st.subheader("Active scenario")
    st.write(active or "None")
    if st.button("Clear active scenario", use_container_width=True):
        st.session_state.pop("active_scenario", None)
        st.success("Cleared.")
        st.rerun()

st.divider()
st.subheader("Run demo KPI (Formula Engine)")

# Choose which KPI set to run
formulas = regs["formulas"]
ready_codes = sorted(set(formulas.loc[formulas["status"] == "READY_DEMO", "metric_code"].astype(str)))
metric_pick = st.multiselect("KPI set", options=ready_codes, default=ready_codes)

if st.button("Run now", use_container_width=True):
    pv = st.session_state.get("param_values") or {}
    alias = st.session_state.get("param_alias") or {}
    ctx = {"params": pv, "param_alias": alias}

    results = eval_metrics(repo_root, metric_codes=set(metric_pick), ctx=ctx)
    out = {
        "meta": {
            "generated_at": datetime.utcnow().isoformat() + "Z",
            "active_scenario": st.session_state.get("active_scenario"),
            "metric_count": len(metric_pick),
        },
        "metrics": {k: {"value": v.value, "note": v.note, "status": v.status} for k, v in results.items()},
    }

    # append-only log
    run_log = repo_root / "data" / "append_only" / "scenario_runs.jsonl"
    run_log.parent.mkdir(parents=True, exist_ok=True)
    append_jsonl(run_log, out)
    st.success("Run logged (append-only). Scroll down to see recent runs.")
    st.session_state["last_run"] = out

if "last_run" in st.session_state:
    st.subheader("Last run output")
    st.json(st.session_state["last_run"])

st.divider()
st.subheader("Recent scenario runs (append-only log)")
run_log = repo_root / "data" / "append_only" / "scenario_runs.jsonl"
rows = read_jsonl(run_log)
if rows:
    st.dataframe(rows[-200:], use_container_width=True)
else:
    st.info("Chưa có run.")
