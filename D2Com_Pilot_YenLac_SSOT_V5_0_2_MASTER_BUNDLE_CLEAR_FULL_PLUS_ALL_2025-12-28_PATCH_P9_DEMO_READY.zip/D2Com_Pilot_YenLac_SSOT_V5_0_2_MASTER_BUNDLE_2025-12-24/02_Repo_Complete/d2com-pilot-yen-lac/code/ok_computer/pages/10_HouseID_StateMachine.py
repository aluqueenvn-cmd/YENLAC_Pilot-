from pathlib import Path

import streamlit as st

from registry_loader import load_registries
from utils.board_metrics import compute_board_metrics

st.set_page_config(page_title="House_ID State Machine", layout="wide")

st.title("🧭 House_ID state machine (Máy trạng thái House_ID)")
st.caption("Trực quan hoá 5 trạng thái: SHADOW→QUALIFIED→CLAIMED→FINANCIAL→GOLDEN. Demo GD1 hiện chưa có event đẩy lên GOLDEN.")

regs = load_registries()
repo_root = Path(regs["repo_root"])

bm = compute_board_metrics(repo_root)
counts = bm.get("house_state_counts", {}) or {}

# order
states = ["SHADOW", "QUALIFIED", "CLAIMED", "FINANCIAL", "GOLDEN"]
labels = {
    "SHADOW": "SHADOW (bóng dữ liệu: mới phát hiện)",
    "QUALIFIED": "QUALIFIED (đủ điều kiện: đã chuẩn hoá)",
    "CLAIMED": "CLAIMED (đã consent/đã claim)",
    "FINANCIAL": "FINANCIAL (đã có giao dịch/tiền)",
    "GOLDEN": "GOLDEN (hồ sơ vàng: vận hành vòng đời)"
}

values = [int(counts.get(s, 0)) for s in states]

# simple inline SVG
W, H = 1100, 220
node_w, node_h = 180, 80
x0, y0 = 40, 70
gap = 40

nodes = []
for i, s in enumerate(states):
    x = x0 + i * (node_w + gap)
    nodes.append((x, y0, s, values[i]))

# Build SVG
svg_parts = [f"<svg xmlns='http://www.w3.org/2000/svg' width='{W}' height='{H}'>"]
svg_parts.append("<defs><marker id='arrow' markerWidth='10' markerHeight='10' refX='9' refY='3' orient='auto'><path d='M0,0 L0,6 L9,3 z' fill='#333'/></marker></defs>")

# arrows
for i in range(len(nodes)-1):
    x1 = nodes[i][0] + node_w
    y1 = nodes[i][1] + node_h/2
    x2 = nodes[i+1][0]
    y2 = nodes[i+1][1] + node_h/2
    svg_parts.append(f"<line x1='{x1}' y1='{y1}' x2='{x2}' y2='{y2}' stroke='#333' stroke-width='2' marker-end='url(#arrow)'/>")

# nodes
for x, y, s, v in nodes:
    svg_parts.append(f"<rect x='{x}' y='{y}' rx='16' ry='16' width='{node_w}' height='{node_h}' fill='#f7f7f7' stroke='#333' stroke-width='2'/>")
    svg_parts.append(f"<text x='{x+node_w/2}' y='{y+32}' text-anchor='middle' font-size='16' fill='#111'>{s}</text>")
    svg_parts.append(f"<text x='{x+node_w/2}' y='{y+58}' text-anchor='middle' font-size='14' fill='#111'>count: {v}</text>")

svg_parts.append("</svg>")
svg = "\n".join(svg_parts)

st.markdown(svg, unsafe_allow_html=True)

st.divider()
st.subheader("Giải nghĩa ngắn gọn")
for s in states:
    st.write(f"- **{s}**: {labels[s]}")

st.divider()
st.subheader("Tín hiệu cảnh báo")
st.warning(
    "- QUALIFIED mà treo lâu không sang CLAIMED: thường là tắc consent (xin đồng ý) hoặc UST/CTV làm ẩu.\n"
    "- CLAIMED mà không sang FINANCIAL: thường là tắc giá/đề xuất, hoặc thiếu khảo sát/báo giá chuẩn.\n"
    "- GOLDEN trong GD1 có thể = 0: vì pilot chưa chạy vòng đời dài."
)
