"""threshold_eval.py – Evaluate thresholds.yaml for a metric.

English → Việt:
- threshold: ngưỡng
- tier: cấp độ (1 cảnh báo, 2 siết, 3 dừng)
- param link: nối ngưỡng với tham số (PARAM:<code>)

Nguyên tắc:
- Không bịa: nếu thiếu param thì dùng default từ param_to_threshold_map.yaml (nếu có), nếu vẫn thiếu -> bỏ qua rule.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import yaml


def load_yaml(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def load_thresholds(repo_root: Path) -> Dict[str, Any]:
    return load_yaml(repo_root / "registry" / "thresholds.yaml")


def load_param_to_threshold_map(repo_root: Path) -> Dict[str, Any]:
    p = repo_root / "registry" / "param_to_threshold_map.yaml"
    if not p.exists():
        return {}
    return load_yaml(p)


def resolve_param_value(
    metric_code: str,
    raw: Any,
    params: Optional[Dict[str, Any]],
    param_map: Dict[str, Any],
) -> Optional[float]:
    """Resolve condition value if it is PARAM:<code> or numeric."""
    if raw is None:
        return None

    # direct numeric
    if isinstance(raw, (int, float)):
        return float(raw)

    # string - may be PARAM:<code>
    if isinstance(raw, str):
        s = raw.strip()
        if s.upper().startswith("PARAM:"):
            code = s.split(":", 1)[1].strip()
            if params and code in params and params[code] is not None:
                try:
                    return float(params[code])
                except Exception:
                    return None
            # fallback default from param_to_threshold_map
            m = (param_map.get("map") or {}).get(metric_code) or {}
            if m.get("threshold_param") == code and m.get("default") is not None:
                try:
                    return float(m.get("default"))
                except Exception:
                    return None
            return None

        # numeric in string
        try:
            return float(s)
        except Exception:
            return None

    return None


def op_eval(op: str, v: float, b: float) -> bool:
    if op == ">":
        return v > b
    if op == ">=":
        return v >= b
    if op == "<":
        return v < b
    if op == "<=":
        return v <= b
    if op == "==":
        return v == b
    return False


def normalize_condition(cond: Dict[str, Any]) -> Tuple[str, Any]:
    op = str(cond.get("op") or "").strip()
    v = cond.get("value")
    inc = bool(cond.get("inclusive", False))
    # if inclusive flag is set but op is strict, normalize
    if inc and op in {">", "<"}:
        op = ">=" if op == ">" else "<="
    return op, v


def evaluate_metric(
    repo_root: Path,
    metric_code: str,
    value: Any,
    params: Optional[Dict[str, Any]] = None,
) -> Tuple[str, str]:
    """Return (color, tier_name)."""
    th = load_thresholds(repo_root)
    thr_list = th.get("thresholds") or []
    param_map = load_param_to_threshold_map(repo_root)

    try:
        v = float(value)
    except Exception:
        return "GRAY", "NO_VALUE"

    spec = None
    for t in thr_list:
        if (t.get("metric_code") or "") == metric_code:
            spec = t
            break

    if not spec:
        return "GRAY", "NO_RULE"

    tiers = spec.get("tiers") or []
    # evaluate hard stop first
    tier_order = ["TIER_3_HARD_STOP", "TIER_2_THROTTLE", "TIER_1_WARNING"]
    for tname in tier_order:
        for t in tiers:
            if t.get("tier") != tname:
                continue
            cond = t.get("condition") or {}
            op, raw_b = normalize_condition(cond)
            b = resolve_param_value(metric_code, raw_b, params, param_map)  # numeric boundary
            if b is None:
                continue
            if op_eval(op, v, b):
                color = "RED" if tname == "TIER_3_HARD_STOP" else "AMBER"
                return color, tname

    return "GREEN", "NONE"
