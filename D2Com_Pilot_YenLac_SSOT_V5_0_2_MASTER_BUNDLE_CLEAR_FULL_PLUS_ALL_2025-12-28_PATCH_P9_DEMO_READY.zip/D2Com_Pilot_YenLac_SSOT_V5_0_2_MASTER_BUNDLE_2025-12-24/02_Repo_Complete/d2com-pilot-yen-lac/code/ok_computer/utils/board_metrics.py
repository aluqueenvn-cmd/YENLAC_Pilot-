"""board_metrics.py – Board (HĐQT) metric helpers

Chỉ dùng cho demo, tập trung vào KPI lõi theo tư duy House_ID state machine.

English → Việt:
- board view: màn hình HĐQT
- state machine: máy trạng thái (chuỗi trạng thái)
- SLA: cam kết thời gian phục vụ
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Tuple

import yaml


def parse_iso(ts: str) -> datetime:
    # tolerate 'Z'
    if ts.endswith('Z'):
        ts = ts[:-1] + '+00:00'
    try:
        return datetime.fromisoformat(ts)
    except Exception:
        return datetime.now(timezone.utc)


def read_jsonl(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    out: List[Dict[str, Any]] = []
    with path.open('r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except Exception:
                continue
    return out


def load_event_registry(repo_root: Path) -> Dict[str, Any]:
    p = repo_root / 'registry' / 'events.yaml'
    obj = yaml.safe_load(p.read_text(encoding='utf-8')) if p.exists() else {}
    return obj or {}


def build_state_transition_map(repo_root: Path) -> Dict[str, str]:
    """event_code -> target_state (house_lifecycle.to)"""
    reg = load_event_registry(repo_root)
    m: Dict[str, str] = {}
    for e in (reg.get('events') or []):
        si = e.get('state_impact') or {}
        hl = si.get('house_lifecycle') if isinstance(si, dict) else None
        if isinstance(hl, dict) and hl.get('to'):
            m[str(e.get('event_code'))] = str(hl.get('to'))
    return m


def compute_house_states(repo_root: Path, events: List[Dict[str, Any]]) -> Tuple[Dict[str, str], Dict[str, datetime], Dict[str, datetime]]:
    """Return (state_by_house, last_event_ts_by_house, last_qualified_ts_by_house)."""
    to_state = build_state_transition_map(repo_root)

    state: Dict[str, str] = {}
    last_ts: Dict[str, datetime] = {}
    last_qualified: Dict[str, datetime] = {}

    # sort by event_ts
    def key(e):
        return parse_iso(str(e.get('event_ts') or e.get('ingest_ts') or '1970-01-01T00:00:00+00:00'))

    for e in sorted(events, key=key):
        house_id = (e.get('payload') or {}).get('house_id') or e.get('house_id')
        if not house_id:
            continue
        ev_code = str(e.get('event_code') or '')
        ts = key(e)
        last_ts[house_id] = ts

        if ev_code in to_state:
            new_state = to_state[ev_code]
            state[house_id] = new_state
            if new_state == 'QUALIFIED':
                last_qualified[house_id] = ts

    # default state for seen houses but no transition yet
    for hid in last_ts.keys():
        state.setdefault(hid, 'SHADOW')

    return state, last_ts, last_qualified


def compute_board_metrics(repo_root: Path) -> Dict[str, Any]:
    """Compute a compact metric set for HĐQT view.

    Output keys use metric_code-like names where possible.
    """
    store_root = Path(os.environ.get('D2COM_STORE_ROOT', str(repo_root))).resolve()
    data_root = store_root / 'data'
    ev_path = data_root / 'event_store' / 'event_log.jsonl'
    q_path = data_root / 'quarantine' / 'quarantine_events.jsonl'
    consent_risk_path = data_root / 'audit' / 'consent_risk.jsonl'

    events = read_jsonl(ev_path)
    quarantined = read_jsonl(q_path)
    consent_risk = read_jsonl(consent_risk_path)

    # normalize: event_log entries wrap payload
    flat_events: List[Dict[str, Any]] = []
    for r in events:
        if isinstance(r, dict) and 'payload' in r:
            # inject house_id into top-level to simplify
            payload = r.get('payload') or {}
            if isinstance(payload, dict) and payload.get('house_id') and not r.get('house_id'):
                r['house_id'] = payload.get('house_id')
            flat_events.append(r)

    state_by_house, last_ts_by_house, last_qualified_by_house = compute_house_states(repo_root, flat_events)

    # Counts
    unique_houses = len(state_by_house)
    state_counts: Dict[str, int] = {}
    for st in state_by_house.values():
        state_counts[st] = state_counts.get(st, 0) + 1

    # pending consent aging: houses currently QUALIFIED and not CLAIMED
    now = datetime.now(timezone.utc)
    pending_ages: List[float] = []
    for hid, st in state_by_house.items():
        if st == 'QUALIFIED':
            t0 = last_qualified_by_house.get(hid)
            if t0:
                pending_ages.append((now - t0).total_seconds() / 3600.0)

    pending_consent_aging_hours = max(pending_ages) if pending_ages else 0.0
    pending_consent_over_48h = sum(1 for h in pending_ages if h >= 48)

    # consent_rate: among houses ever QUALIFIED, proportion that reached CLAIMED or beyond
    qualified_houses = set(last_qualified_by_house.keys())
    consented_houses = {hid for hid, st in state_by_house.items() if st in ('CLAIMED', 'FINANCIAL', 'GOLDEN')}
    consent_rate = (len(consented_houses & qualified_houses) / len(qualified_houses)) if qualified_houses else 0.0

    # unconsented_pii_risk: count consent violations in consent_risk log (point-in-time sum)
    unconsented_pii_risk = sum(1 for r in consent_risk if r.get('metric_code') == 'unconsented_pii_risk')

    # SLA lead_to_survey
    def first_ts(event_code: str, hid: str) -> datetime | None:
        for e in sorted(flat_events, key=lambda x: parse_iso(str(x.get('event_ts') or x.get('ingest_ts') or '1970-01-01T00:00:00+00:00'))):
            ehid = (e.get('payload') or {}).get('house_id') or e.get('house_id')
            if ehid != hid:
                continue
            if str(e.get('event_code')) == event_code:
                return parse_iso(str(e.get('event_ts') or e.get('ingest_ts')))
        return None

    lead_to_survey_hours: List[float] = []
    for hid in state_by_house.keys():
        t_lead = first_ts('EVT_ENG_LEAD_CREATED', hid)
        t_survey = first_ts('EVT_TRX_SITE_SURVEY_STARTED', hid)
        if t_lead and t_survey and t_survey >= t_lead:
            lead_to_survey_hours.append((t_survey - t_lead).total_seconds() / 3600.0)

    sla_lead_to_survey_hours_p90 = 0.0
    if lead_to_survey_hours:
        xs = sorted(lead_to_survey_hours)
        idx = int(0.9 * (len(xs) - 1))
        sla_lead_to_survey_hours_p90 = xs[idx]

    # Stuck rate: houses with last event older than 72h and state not FINANCIAL/GOLDEN
    stuck_cut = 72.0
    stuck = 0
    for hid, ts in last_ts_by_house.items():
        age_h = (now - ts).total_seconds() / 3600.0
        if age_h >= stuck_cut and state_by_house.get(hid) not in ('FINANCIAL', 'GOLDEN'):
            stuck += 1
    stuck_rate_critical = (stuck / unique_houses) if unique_houses else 0.0


    # Event counts (đếm sự kiện) – phục vụ HĐQT soi nhịp vận hành
    event_counts: Dict[str, int] = {}
    for e in flat_events:
        code = str(e.get('event_code') or '')
        if not code:
            continue
        event_counts[code] = event_counts.get(code, 0) + 1

    lead_created_count = event_counts.get('EVT_ENG_LEAD_CREATED', 0)
    survey_started_count = event_counts.get('EVT_TRX_SITE_SURVEY_STARTED', 0)
    survey_completed_count = event_counts.get('EVT_TRX_SITE_SURVEY_COMPLETED', 0)
    cash_collected_count = event_counts.get('EVT_FIN_CASH_COLLECTED', 0)

    return {
        'unique_house_count': unique_houses,
        'house_state_counts': state_counts,
        'pending_consent_aging_hours': round(pending_consent_aging_hours, 2),
        'pending_consent_over_48h_count': int(pending_consent_over_48h),
        'consent_rate': round(consent_rate, 4),
        'unconsented_pii_risk': int(unconsented_pii_risk),
        'quarantine_count': int(len(quarantined)),
        'sla_lead_to_survey_hours_p90': round(sla_lead_to_survey_hours_p90, 2),
        'stuck_rate_critical': round(stuck_rate_critical, 4),
        'lead_created_count': int(lead_created_count),
        'survey_started_count': int(survey_started_count),
        'survey_completed_count': int(survey_completed_count),
        'cash_collected_count': int(cash_collected_count),
    }
