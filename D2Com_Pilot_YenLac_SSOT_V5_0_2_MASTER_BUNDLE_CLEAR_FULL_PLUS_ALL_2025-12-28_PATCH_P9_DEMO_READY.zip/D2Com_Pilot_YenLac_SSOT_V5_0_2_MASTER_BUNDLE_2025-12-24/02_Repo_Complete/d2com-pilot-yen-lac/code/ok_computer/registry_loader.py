from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Optional

import pandas as pd
import yaml

# Ensure repo_root/code is on sys.path so we can import core package
import sys

def _ensure_code_on_path(repo_root: Path) -> None:
    code_root = repo_root / 'code'
    if str(code_root) not in sys.path:
        sys.path.insert(0, str(code_root))


def repo_root_from_here() -> Path:
    # repo_root/code/ok_computer/registry_loader.py -> repo_root
    return Path(__file__).resolve().parents[2]

# Bootstrap sys.path for core imports (needed by pages)
_ensure_code_on_path(repo_root_from_here())


def load_yaml(path: Path) -> Any:
    with path.open('r', encoding='utf-8') as f:
        return yaml.safe_load(f) or {}


def load_alias(path: Path) -> Dict[str, str]:
    if not path.exists():
        return {}
    data = load_yaml(path) or {}
    if isinstance(data, dict) and 'aliases' in data and isinstance(data['aliases'], dict):
        data = data['aliases']
    if not isinstance(data, dict):
        return {}
    out: Dict[str, str] = {}
    for k, v in data.items():
        if isinstance(v, str):
            out[str(k)] = v
    return out


def load_registries(repo_root: Optional[Path] = None) -> Dict[str, Any]:
    root = repo_root or repo_root_from_here()
    _ensure_code_on_path(root)
    reg = root / 'registry'
    return {
        'repo_root': str(root),
        'events': load_yaml(reg / 'events.yaml'),
        'metrics': pd.read_csv(reg / 'metrics.csv', encoding='utf-8-sig'),
        'formulas': pd.read_csv(reg / 'formulas.csv', encoding='utf-8-sig') if (reg / 'formulas.csv').exists() else pd.DataFrame(),
        'metric_alias': load_alias(reg / 'metric_alias.yaml'),
        'gate_matrix': load_yaml(reg / 'gate_matrix.yaml'),
        'causal_edges': load_yaml(reg / 'causal_edges.yaml'),
        'runbook_actions': load_yaml(reg / 'runbook_actions.yaml'),
        'registry_lints': load_yaml(reg / 'registry_lints.yaml'),
        'thresholds': load_yaml(reg / 'thresholds.yaml'),
        'param_alias': load_yaml(reg / 'param_alias.yaml') if (reg / 'param_alias.yaml').exists() else {},
        'param_to_threshold_map': load_yaml(reg / 'param_to_threshold_map.yaml') if (reg / 'param_to_threshold_map.yaml').exists() else {},
        'data_assets': load_yaml(reg / 'data_assets.yaml') if (reg / 'data_assets.yaml').exists() else {},
    }