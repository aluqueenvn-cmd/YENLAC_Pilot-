"""
state.py — Shared Streamlit session state for Params & Scenarios.

English → Việt:
- session_state: bộ nhớ phiên (giữ giữa các pages)
- param values: giá trị tham số
- scenario: kịch bản (ghi đè tham số)
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import streamlit as st

from registry_loader import repo_root_from_here
from core.param_store import (
    ParamDef,
    apply_overrides,
    build_default_param_values,
    load_param_defs,
)
from core.scenario_store import Scenario, load_scenarios_from_excel


def get_repo_root() -> Path:
    return repo_root_from_here()


def _default_param_paths(repo_root: Path) -> Tuple[Optional[Path], List[Path]]:
    params_dir = repo_root / "demo_inputs" / "params"
    if not params_dir.exists():
        return None, []

    primary = None
    # pick most recent CoreSoft param master by filename
    cands = sorted(params_dir.glob("Param_Master_CoreSoft*.xlsx"))
    if cands:
        primary = cands[-1]

    addons = sorted(params_dir.glob("Param_Master_Threshold_AddOn*.xlsx"))
    return primary, addons


def _default_scenario_path(repo_root: Path) -> Optional[Path]:
    scen_dir = repo_root / "demo_inputs" / "scenario"
    if not scen_dir.exists():
        return None
    cands = sorted(scen_dir.glob("Scenario_Library*.xlsx"))
    return cands[-1] if cands else None


def ensure_params_loaded(repo_root: Optional[Path] = None) -> None:
    repo_root = repo_root or get_repo_root()
    if "param_defs" in st.session_state and "param_values" in st.session_state:
        return

    primary, addons = _default_param_paths(repo_root)
    if primary is None:
        st.session_state["param_defs"] = []
        st.session_state["param_alias"] = {}
        st.session_state["param_values"] = {}
        st.session_state["param_sources"] = {"primary": None, "addons": []}
        return

    defs, alias = load_param_defs(repo_root, primary_excel=primary, addon_excels=addons)
    base = build_default_param_values(defs)

    st.session_state["param_defs"] = defs
    st.session_state["param_alias"] = alias
    st.session_state["param_values"] = base
    st.session_state["param_sources"] = {"primary": str(primary), "addons": [str(p) for p in addons]}


def ensure_scenarios_loaded(repo_root: Optional[Path] = None) -> None:
    repo_root = repo_root or get_repo_root()
    if "scenarios" in st.session_state:
        return
    p = _default_scenario_path(repo_root)
    if p is None:
        st.session_state["scenarios"] = {}
        st.session_state["scenario_source"] = None
        return
    st.session_state["scenarios"] = load_scenarios_from_excel(p)
    st.session_state["scenario_source"] = str(p)


def apply_scenario(scenario_id: str) -> None:
    ensure_params_loaded()
    ensure_scenarios_loaded()
    sc: Scenario = st.session_state["scenarios"].get(scenario_id)
    if not sc:
        return
    alias = st.session_state.get("param_alias") or {}
    base = st.session_state.get("param_values") or {}
    st.session_state["param_values"] = apply_overrides(base, sc.overrides, alias=alias)
    st.session_state["active_scenario"] = scenario_id



def ensure_data_source(repo_root: Path) -> Path:
    # Data source selector (DEMO_INPUTS vs DEMO_STORE vs REPO_DATA)
    import os

    # Candidate modes
    modes = [
        "DEMO_INPUTS",  # read demo_inputs fallback (no store root override)
        "DEMO_STORE",   # read demo_out/store (built by build_demo_store.py)
        "REPO_DATA",    # read repo_root/data (if user ingested into repo)
    ]

    default_mode = st.session_state.get("data_source_mode", "DEMO_INPUTS")
    if default_mode not in modes:
        default_mode = "DEMO_INPUTS"

    st.sidebar.divider()
    st.sidebar.subheader("Data source")
    mode = st.sidebar.selectbox(
        "Chọn nguồn dữ liệu (store)",
        options=modes,
        index=modes.index(default_mode),
        help=(
            "DEMO_INPUTS: chạy ngay trên demo_inputs (fallback).\n"
            "DEMO_STORE: chạy trên data store chuẩn hóa (demo_out/store).\n"
            "REPO_DATA: chạy trên repo_root/data (nếu đã ingest vào repo)."
        ),
    )

    st.session_state["data_source_mode"] = mode

    if mode == "DEMO_STORE":
        store_root = repo_root / "demo_out" / "store"
        os.environ["D2COM_STORE_ROOT"] = str(store_root)
        if not (store_root / "data").exists():
            st.sidebar.warning("DEMO_STORE chưa tồn tại. Chạy: python code/scripts/build_demo_store.py")
    elif mode == "REPO_DATA":
        os.environ["D2COM_STORE_ROOT"] = str(repo_root)
    else:
        os.environ.pop("D2COM_STORE_ROOT", None)

    active = os.environ.get("D2COM_STORE_ROOT", "(repo_root + demo_inputs fallback)")
    st.sidebar.caption(f"Store root: {active}")

    return Path(os.environ.get("D2COM_STORE_ROOT") or repo_root)
