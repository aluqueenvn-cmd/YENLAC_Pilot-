import subprocess
import sys
from pathlib import Path


def test_smoke_ready_demo_pack():
    repo_root = Path(__file__).resolve().parents[1]
    cmd = [
        sys.executable,
        str(repo_root / "code" / "scripts" / "smoke_demo_pack.py"),
        "--pack",
        "READY_DEMO_30",
        "--build_store",
    ]
    res = subprocess.run(cmd, cwd=str(repo_root), capture_output=True, text=True)
    assert res.returncode == 0, f"stdout:\n{res.stdout}\nstderr:\n{res.stderr}"
