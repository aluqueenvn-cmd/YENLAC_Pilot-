from pathlib import Path
import json

from core.formula_dsl_v1 import eval_dsl_v1


def test_rate_entities_duration_lte(tmp_path: Path):
    # Minimal temp repo: registry + event_store/event_log.jsonl
    repo_root = Path(__file__).resolve().parents[1]
    temp_repo = tmp_path / "repo"
    temp_repo.mkdir()

    import shutil
    shutil.copytree(repo_root / "registry", temp_repo / "registry")

    ev_dir = temp_repo / "data" / "event_store"
    ev_dir.mkdir(parents=True)

    # H1: 5h, H2: 15h
    events = [
        {"event_code": "EVT_ENG_LEAD_CREATED", "event_ts": "2025-12-24T00:00:00+07:00", "house_id": "H1"},
        {"event_code": "EVT_TRX_SITE_SURVEY_STARTED", "event_ts": "2025-12-24T05:00:00+07:00", "house_id": "H1"},
        {"event_code": "EVT_ENG_LEAD_CREATED", "event_ts": "2025-12-24T00:00:00+07:00", "house_id": "H2"},
        {"event_code": "EVT_TRX_SITE_SURVEY_STARTED", "event_ts": "2025-12-24T15:00:00+07:00", "house_id": "H2"},
    ]
    (ev_dir / "event_log.jsonl").write_text("\n".join(json.dumps(e, ensure_ascii=False) for e in events) + "\n", encoding="utf-8")

    dsl = {
        "dsl_version": "1.0",
        "expr": {
            "op": "rate_entities_duration_lte",
            "table": "event_log",
            "entity_key": "house_id",
            "start_event": "EVT_ENG_LEAD_CREATED",
            "end_event": "EVT_TRX_SITE_SURVEY_STARTED",
            "threshold_hours": 10,
        },
    }

    res = eval_dsl_v1(temp_repo, dsl)
    assert res.value == 0.5
