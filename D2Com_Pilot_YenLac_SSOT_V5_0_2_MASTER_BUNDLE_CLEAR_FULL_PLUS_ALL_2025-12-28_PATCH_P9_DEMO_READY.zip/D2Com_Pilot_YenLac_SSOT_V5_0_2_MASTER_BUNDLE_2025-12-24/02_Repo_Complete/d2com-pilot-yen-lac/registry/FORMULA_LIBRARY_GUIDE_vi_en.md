# Formula Library (Thư viện công thức) – V5.0.2

## Mục đích
- **Formula Library (Thư viện công thức)** là “bảng tra” để **máy tính** và **người** hiểu *một KPI được tính như thế nào*.
- Nó là cầu nối giữa:
  - **metrics.csv** (Danh mục KPI: tên, định nghĩa, đơn vị, cửa sổ thời gian)
  - và **KPI Engine (Bộ máy tính KPI)** trong code.

## File chuẩn
- `registry/formulas.csv`

## Nguyên tắc khóa (invariants – nguyên tắc bất biến)
1. `metrics.csv.formula_id` **phải** tồn tại trong `formulas.csv.formula_id`.
2. `formulas.csv.formula_id` **không được trùng**.
3. `formulas.csv.metric_code` (nếu có) **phải khớp** đúng 1 KPI trong `metrics.csv`.

## Ý nghĩa các cột trong formulas.csv
- `formula_id`: Mã công thức (ví dụ `F-K0-04`).
- `metric_code`: Mã KPI (ví dụ `pending_consent_aging_hours`).
- `metric_name_vi` / `metric_name_en`: Tên KPI tiếng Việt / tiếng Anh.
- `k_level`: Tầng KPI (K0…K8).
- `unit`: Đơn vị (count = số lượng; rate = tỷ lệ; pct = phần trăm; hours = giờ; vnd = tiền Việt).
- `window`: Cửa sổ thời gian (time window – khoảng tính), ví dụ `7d`, `rolling_30d`, `point-in-time`.
- `expression_vi`: Mô tả công thức bằng tiếng Việt (dạng đọc hiểu).
- `expression_dsl`: Công thức “dạng máy đọc” (DSL – ngôn ngữ công thức). Có thể để trống nếu chưa chốt.
- `inputs_required`: Input tối thiểu (bảng dữ liệu, event cần có, khóa drilldown).
- `status`:
  - `READY_DEMO`: đã có logic chạy demo trong code.
  - `PLACEHOLDER`: mới khóa cấu trúc, chưa chốt công thức máy tính.
- `evidence_ref`: Nguồn bằng chứng (file/đoạn code) chứng minh công thức.
- `notes`: ghi chú.
- `last_updated`: ngày cập nhật.

## Tình trạng hiện tại (as-is)
- File này **được thêm vào để khóa cấu trúc** (schema) và ngăn “drift” (trôi chuẩn) giữa SSOT và code.
- Một số KPI lõi đã có công thức demo (`READY_DEMO`) dựa trên `board_metrics.py`.
- Phần còn lại để `PLACEHOLDER` vì SSOT hiện tại **chưa có công thức chuẩn** dạng máy đọc cho toàn bộ 87 KPI.

## Bước tiếp theo (to-be)
- Chốt **DSL chuẩn** (ví dụ: `COUNT_DISTINCT`, `SUM`, `RATIO`, `P90_DURATION`) và viết **KPI Engine** đọc `formulas.csv` để tính tự động.
- Với KPI nào chưa đủ dữ liệu nguồn (source events/tables), gắn nhãn rõ và bổ sung Event Spec hoặc Data Dictionary.
