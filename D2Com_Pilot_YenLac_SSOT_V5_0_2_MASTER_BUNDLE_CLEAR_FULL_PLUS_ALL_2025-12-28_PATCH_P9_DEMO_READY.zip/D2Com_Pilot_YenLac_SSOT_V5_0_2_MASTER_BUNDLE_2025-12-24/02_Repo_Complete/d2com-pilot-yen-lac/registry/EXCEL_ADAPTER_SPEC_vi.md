# Excel → App Adapter Spec (Đặc tả đấu nối Excel vào Streamlit) – V5.0.2

Mục tiêu: đọc **Param Master** và **Scenario Library** từ Excel để feed vào Model Lab / Scenario Panel mà không phá SSOT.

## A. Param Master Excel (tham số gốc)
File ví dụ: `Param_Master_CoreSoft59_*.xlsx`

### Sheet: `PARAM_MASTER`
Cột tối thiểu:
- `param_code` (mã tham số chuẩn, UPPER_SNAKE)
- `param_value` (giá trị)
- `param_unit` (đơn vị)
- `param_type` (int/float/bool/string)
- `scope` (pilot/xã/toàn hệ)
- `notes` (ghi chú)

### Alias
Nếu Excel dùng tên khác, tra trong `registry/param_alias.yaml::aliases` để quy đổi về `param_code` chuẩn.

## B. Scenario Library Excel (kịch bản)
File ví dụ: `Scenario_Library_*.xlsx`

### Sheet: `SCENARIO_LIBRARY`
Cột tối thiểu:
- `scenario_code` (BASE/BEST/WORST/S01..)
- `scenario_name`
- `description_vi`

### Sheet: `SCENARIO_OVERRIDES`
Cột tối thiểu:
- `scenario_code`
- `param_code`
- `override_value`

## C. Output chuẩn để app đọc
App có thể chọn 1 trong 2 cách:
1) **Đọc trực tiếp Excel** (khuyến nghị cho war-room): app đọc file ở `data/scenario/`.
2) **Export JSON** (khuyến nghị CI/CD): xuất ra `data/scenario/scenarios.json` theo schema:

```json
{
  "scenario_code":"S01",
  "overrides":{"PARAM_A":123, "PARAM_B":0.5}
}
```

## D. Nguyên tắc bất biến
- Không ghi đè registry. Excel chỉ là **input runtime**.
- Mọi thay đổi tham số phải có Evidence Ledger/Patch Log ở `patch_ledger/`.
