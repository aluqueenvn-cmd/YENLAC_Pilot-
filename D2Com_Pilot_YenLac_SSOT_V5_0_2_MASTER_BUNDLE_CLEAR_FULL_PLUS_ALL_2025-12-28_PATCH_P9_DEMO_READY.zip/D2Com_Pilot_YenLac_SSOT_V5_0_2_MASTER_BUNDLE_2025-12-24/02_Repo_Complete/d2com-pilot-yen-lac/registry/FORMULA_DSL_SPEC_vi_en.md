# Formula DSL Spec (Đặc tả ngôn ngữ công thức) - V5.0.2

## 1) DSL là gì?
- **DSL (Domain-Specific Language)** = **ngôn ngữ chuyên biệt theo miền**.
- Ở đây: DSL dùng để mô tả *công thức KPI* theo kiểu **máy đọc được**, thay vì chỉ viết mô tả bằng chữ.

## 2) DSL nằm ở đâu?
- File: `registry/formulas.csv`
- Cột: `expression_dsl`

## 3) DSL Version hiện tại (DSL_V0)
### Mục tiêu
- Chạy **demo** nhanh cho các KPI lõi (K0) đang được tính trong code (board_metrics).

### Định dạng
`expression_dsl` là **chuỗi JSON** (JSON string). Ví dụ:
```json
{"fn":"BOARD_METRICS","key":"consent_rate"}
```

### Trường bắt buộc
- `fn`: tên hàm tính (function name).
- `key`: tên khoá kết quả trong output.

### fn hỗ trợ (V0)
- `BOARD_METRICS`: gọi trực tiếp hàm demo `compute_board_metrics()` và lấy kết quả theo `key`.

### Ví dụ
- `pending_consent_aging_hours`
```json
{"fn":"BOARD_METRICS","key":"pending_consent_aging_hours"}
```

## 4) Mapping dữ liệu đầu vào (Input mapping)
- DSL **không tự đoán** dữ liệu.
- `inputs_required` trong `formulas.csv` ghi rõ:
  - cần bảng nào (tables)
  - file nào (paths)
  - khóa drilldown (keys)

Ví dụ:
- `tables:event_log | paths:data/event_store/event_log.jsonl | keys:house_id`

## 5) Hướng mở rộng (DSL_V1 - kế hoạch)
> Mục này là định hướng để sau này viết KPI Engine tổng quát (không hard-code).

Các primitive (viên gạch cơ bản) đề xuất:
- `COUNT`, `COUNT_DISTINCT` (đếm / đếm không trùng)
- `SUM`, `AVG`, `MIN`, `MAX`
- `RATIO(num, den)` (tỷ lệ)
- `DURATION_HOURS(t_start, t_end)` (thời lượng tính giờ)
- `FILTER(where=...)` (lọc)
- `WINDOW(7d/30d/point-in-time)` (cửa sổ thời gian)

Nếu làm DSL_V1 thì nên lưu DSL dạng JSON/YAML có schema rõ để tránh “trôi chuẩn”.




---
## PATCH P3-DSL-V1 (DEMO_15 KPI) – 2025-12-27

### Mục tiêu
- Nâng từ 4 KPI READY_DEMO (BOARD_METRICS) lên **DEMO_15** KPI chạy end-to-end bằng DSL (máy đọc được).
- Không phá V0: DSL cũ dạng `{"fn":"BOARD_METRICS","key":"..."}` vẫn chạy như trước.

### DSL V1 định dạng
- Lưu trong cột `registry/formulas.csv::expression_dsl` dưới dạng **JSON string**.
- Nhận diện DSL V1 bằng khóa: `dsl_version: "1.0"`.

### Schema tối thiểu (JSON)
```json
{
  "dsl_version": "1.0",
  "expr": {
    "op": "count | count_distinct | sum | avg | ratio | ...",
    "source": { "table": "event_log | house_master | job_master | finance_ledger" }
  }
}
```

### `source.table`
- `event_log` (kho sự kiện append-only)
- `house_master` (danh bạ nhà)
- `job_master` (danh bạ job)
- `finance_ledger` (sổ thu-chi; hiện mới thêm vào registry để mô phỏng)

### Các toán tử (op) đã implement cho DEMO_15
Nhóm thống kê cơ bản:
- `count`
- `count_distinct`
- `sum`
- `avg`
- `ratio` (num/den, có safe-divide)

Nhóm SLA/duration theo **entity** (thực tế cho K2/K4):
- `rate_entities_duration_lte` (tỷ lệ entity có duration <= ngưỡng)
- `rate_entities_without_event` (tỷ lệ entity không có “bad_event” trước/đến end_event)
- `avg_entities_duration_days_between_events` (trung bình số ngày từ start_event -> end_event)
- `avg_entities_duration_hours_between_events` (trung bình số giờ từ start_event -> end_event)

### `where` filter (lọc) – dạng biểu thức boolean
Các op đã hỗ trợ:
- `eq` (bằng)
- `in` (nằm trong danh sách)
- `and` (tất cả đúng)
- `or` (ít nhất 1 đúng)
- `exists` (field tồn tại và không rỗng)

Ví dụ lọc theo payload:
```json
{
  "op":"and",
  "args":[
    {"op":"eq","field":"event_code_canonical","value":"EVT_FIN_CASH_COLLECTED"},
    {"op":"eq","field":"payload.cash_type","value":"DEPOSIT"}
  ]
}
```

### Field naming (chuẩn hóa tên cột)
Để giữ tương thích dữ liệu:
- `event_code_canonical` == `event_code`
- `event_at` == `event_ts`
- `ingested_at` == `ingest_ts`

### Ví dụ hoàn chỉnh
1) Đếm lead created:
```json
{
  "dsl_version":"1.0",
  "expr":{
    "op":"count",
    "source":{"table":"event_log"},
    "where":{"op":"eq","field":"event_code_canonical","value":"EVT_ENG_LEAD_CREATED"}
  }
}
```

2) SLA on-time rate (<= 240h) từ job_started -> handover_signed:
```json
{
  "dsl_version":"1.0",
  "expr":{
    "op":"rate_entities_duration_lte",
    "source":{"table":"event_log"},
    "entity_key":"job_id",
    "start_event":"EVT_TRX_JOB_STARTED",
    "end_event":"EVT_TRX_HANDOVER_SIGNED",
    "threshold_hours":240
  }
}
```

### Ghi chú về an toàn
- DSL V1 chỉ là **whitelist ops** (không eval code tùy ý).
- Mọi truy cập PII phải đi qua consent gate; không có đường tắt trong DSL.
