# Completeness Checklist – P4 (27/12/2025) – SSOT V5.0.2

Checklist này chia 2 lớp:
- **Người đọc**: đọc hiểu logic (Hiến Pháp, Patch Ledger, Playbook, Governance) và tìm đúng file.
- **Máy đọc**: chạy được demo (Streamlit + Formula Engine DSL V1 + Excel adapters) với dữ liệu demo.

## A. Người đọc (Human-read | đọc cho người)
1) **Start here (Bắt đầu từ đây)**
- 00_README/README_MASTER_BUNDLE.md
- 01_SSOT_Core/HienPhap_*.md hoặc .docx

2) **Patch & quyết định (append-only)
- 04_Patch_Ledger/patch_ledger/patch_decision_log.md
- P4_Excel_Adapters_HDQT_Threshold_ParamLink_2025-12-27.md

3) **Glossary song ngữ**
- 03_Registry/registry/glossary.csv (vi/en + definition_vi)

4) **Khung K0–K8 + kill-switch**
- docs/board/HOUSE_ID_STATE_MACHINE.md
- docs/board/KILL_SWITCH_CONSENT_RISK.md

## B. Máy đọc (Machine-read | đọc cho máy)
1) **Repo chạy được**
- 02_Repo_Complete/d2com-pilot-yen-lac/README.md
- requirements.txt / Dockerfile / docker-compose.yml

2) **Registry lint + unit tests**
- python code/scripts/validate_registry.py
- pytest -q

3) **Formula Engine DSL V1**
- registry/formulas.csv: 15 KPI status=READY_DEMO
- code/core/formula_dsl_v1.py + code/core/formula_engine.py

4) **Excel adapters**
- demo_inputs/params/Param_Master_CoreSoft59_*.xlsx
- demo_inputs/params/Param_Master_Threshold_AddOn_*.xlsx
- demo_inputs/scenario/Scenario_Library_*.xlsx

5) **Streamlit pages (HĐQT view lấy KPI từ engine)**
- code/ok_computer/pages/07_Scenario_Panel.py
- code/ok_computer/pages/08_Model_Lab.py
- code/ok_computer/pages/09_HDQT_View_K0_K8.py

6) **Audit logs (append-only)**
- 02_Repo_Complete/d2com-pilot-yen-lac/audit/*.jsonl

## C. Nếu muốn “đủ chuẩn production” (khuyến nghị)
- Bổ sung **Evidence Ledger template** (bảng bằng chứng: nguồn, link, hash, người xác nhận) để chống “bịa” ở tầng tham số.
- Nâng DSL coverage từ 15 KPI -> “K0–K8 survival set” (25–35 KPI) và chốt derived tables catalogue.
