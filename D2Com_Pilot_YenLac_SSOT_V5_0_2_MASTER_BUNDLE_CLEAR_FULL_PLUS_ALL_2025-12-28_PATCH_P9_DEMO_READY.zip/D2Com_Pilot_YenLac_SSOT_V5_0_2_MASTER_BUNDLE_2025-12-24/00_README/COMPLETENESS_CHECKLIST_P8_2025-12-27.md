# COMPLETENESS CHECKLIST — P8 (2025-12-27)

## Mục tiêu
- Registry CSV mở trong Excel hiển thị tiếng Việt đúng (UTF-8 BOM), không đổi logic.

## Đã làm
- [x] Thêm UTF-8 BOM vào `metrics.csv`, `formulas.csv`, `glossary.csv` ở cả:
  - `03_Registry/registry/`
  - `02_Repo_Complete/d2com-pilot-yen-lac/registry/`
- [x] Thêm Patch Ledger: `P8-REGISTRY-CSV-UTF8BOM_v5_0_2_2025-12-27.md`
- [x] Regenerate `MANIFEST_FILES.txt` và `MANIFEST_SHA256.txt`

## Tự kiểm nhanh
- Mở `03_Registry/registry/glossary.csv` bằng Excel: chữ Việt không bị lỗi.
- So sánh số dòng trước/sau: giữ nguyên.
