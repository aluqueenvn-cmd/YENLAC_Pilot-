# COMPLETENESS CHECKLIST – Patch P9 (2025-12-28)

## 1) Done trong P9
- ✅ **DEMO_RUN.md** chạy theo 1 luồng chuẩn (validate → build store → smoke → streamlit).
- ✅ Fix `build_demo_store.py` (đúng chữ ký ingest) + xuất derived `event_log_flat.csv`.
- ✅ Fix `formula_dsl_v1.py`: tương thích `source/table`, `entity_field/entity_key` + thêm `start_where` cho duration ops.
- ✅ Chuẩn hoá `demo_inputs/events/events_demo.csv` để **qua schema validation** (đủ required_keys).
- ✅ Chốt **READY_DEMO_30** KPI pack (30 KPI) + `smoke_demo_pack.py`.
- ✅ Thêm smoke test + unit test (pytest pass).
- ✅ Patch note P9 + regen manifest.

## 2) Còn thiếu nhưng KHÔNG làm trong P9 (để giữ gói gọn)
- ⏳ Simulation Engine (scenario → sinh event/cash → KPI) dạng ABM (Agent-Based Modeling = mô phỏng dựa trên tác nhân).
- ⏳ Derived tables nâng cấp: KPI-ready warehouse (fact_event, fact_cash, dim_house, dim_actor), incremental build.
- ⏳ Bộ KPI mở rộng 25–30 KPI theo K0–K8 đầy đủ (hiện đã có 30 KPI demo, nhưng còn thiếu nhiều KPI “ops sâu” và “gov sâu”).
- ⏳ CI/CD nâng hơn: coverage, lint, typing, contract tests.
- ⏳ Demo dữ liệu “giàu” hơn: nhiều xã, nhiều UST/CTV, nhiều lỗi thật (fraud, consent-risk, dispute).

## 3) Nên dừng ở đây chưa?
- Khuyến nghị: **dừng tại P9** làm mốc “demo chạy được, không gãy, có KPI ra số”.
- Lý do: càng nhồi nhiều thứ vào 1 patch sẽ làm SSOT bị phình, khó audit, khó rollback.

## 4) Next patch đề xuất (đánh số để khỏi lạc)
- P10: Simulation Engine MVP (scenario JSON → generate event_log + finance_ledger → compute READY_DEMO_30).
- P11: KPI Pack mở rộng (READY_DEMO_60) + derived warehouse.
- P12: Governance deep (kill-switch drills, incident runbook automation).
