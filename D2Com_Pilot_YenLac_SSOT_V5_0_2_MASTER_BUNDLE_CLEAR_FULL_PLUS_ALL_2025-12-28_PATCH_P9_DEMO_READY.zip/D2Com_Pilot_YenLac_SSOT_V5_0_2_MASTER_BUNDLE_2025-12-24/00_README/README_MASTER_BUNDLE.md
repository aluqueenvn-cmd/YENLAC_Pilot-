# MASTER BUNDLE – D2Com Pilot Yên Lạc – SSOT V5.0.2-Clean (26/12/2025)

## Mục tiêu của gói này
- Gom **tất cả file quan trọng** (SSOT + registry + patch + appendix overlays + repo code) vào 1 chỗ để khỏi lạc.
- Đảm bảo **code đọc SSOT**: mọi thứ vận hành nằm trong `registry/` và `patch_ledger/`.

## Cấu trúc thư mục
- `01_SSOT_Core/`: Hiến Pháp V5.0.2 (bản lõi) + bản skeleton gốc.
- `02_Repo_Complete/`: repo đầy đủ để chạy (Streamlit/OKC + CI + war-room kit).
- `03_Registry/`: copy riêng registry cho dễ nhìn (events/metrics/thresholds/gate/causal/runbook...).
- `04_Patch_Ledger/`: patch records + decision log + MERGELOG.
- `05_Appendix_Overlays/`: A1/A3/A4/A6/A7/A8 canonical aligned (docx+md) để đọc.
- `06_Source_Appendix_Raw/`: bản nguồn/legacy của A2/A4/A5/A6/A7/A8 (giữ audit).
- `07_Input_Data_Sources/`: nguồn dữ liệu gốc (VDCD, phụ lục danh mục dữ liệu, …).
- `08_PatchPacks_And_Zips/`: các zip pack lịch sử (dự phòng).

## Chạy code nhanh
Vào `02_Repo_Complete/d2com-pilot-yen-lac/` rồi:
1) `python -m venv .venv && source .venv/bin/activate` (Windows thì dùng activate)
2) `pip install -r requirements.txt`
3) `python code/scripts/validate_registry.py --repo_root .`
4) `pytest -q`
5) `streamlit run code/ok_computer/app.py`

## Những thứ gói này CÓ (đã khóa)
- House_ID state machine 5 trạng thái UPPERCASE: SHADOW→QUALIFIED→CLAIMED→FINANCIAL→GOLDEN
- Event canonical: `event_code = EVT_*` + idempotency_key
- Gate: No Evidence + Bad Evidence No Pay
- Evidence metric canonical: `evidence_pass_rate` (có alias)
- Thresholds tier 1/2/3 (P1-THRESHOLDS)
- Runbook action cards + rollback + incident SLA + unit test spec

## Những thứ gói này CHƯA BAO GỒM (để mày khỏi hiểu nhầm)
- Dữ liệu thực địa thật (ảnh/UAV/GeoJSON) và kho evidence thật.
- Event store thật để replay KPI (mới có schema/quy tắc).
- Pipeline ingest production (mới có khung + runbook, cần P2-INGEST).

## Ghi chú bản Clean (26/12/2025)
- Sửa lỗi encoding tên file tiếng Việt trong `07_Input_Data_Sources/` và `09_Reference_Docs/`.
- Loại bỏ thư mục cache không cần thiết (`__pycache__`, `.pytest_cache`) trong repo.
- Bổ sung Glossary song ngữ SSOT (`registry/glossary.csv`) và tích hợp vào repo demo Streamlit.
- Bổ sung demo runner (`DEMO_RUN.md`, `demo_inputs/`, các script build_glossary/check_vi) để chạy out-of-box.
- Bổ sung `00_README/MANIFEST_SHA256.txt` để chống “trôi bản”.

## Cập nhật P3 (26/12/2025)
- Thêm **HĐQT View K0–K8** + **House_ID state machine** + **User Guide** ngay trong Streamlit.
- Siết **consent-risk**: record có `pii_*` mà chưa có `consent_flag=true` sẽ **bị quarantine**.
- Thêm **hash chain (chuỗi băm)** để kiểm can thiệp (tamper) (append-only).
- Thêm **API contract (OpenAPI)** cho ingest.
- Thêm Dockerfile + repo hygiene lint.
- Copy bản zip song ngữ chạy demo vào `08_PatchPacks_And_Zips/`.

## Cập nhật P4 (27/12/2025)
- Nâng demo từ “HĐQT view tính tay” sang **HĐQT view đọc Formula Library** (DSL V1) và hiển thị traffic-light theo ngưỡng.
- Thêm **Excel Adapter**:
  - Param Master Excel -> Model Lab (tự sinh UI điều chỉnh tham số theo Param_Code).
  - Scenario Library Excel -> Scenario Panel (Apply scenario + export JSON append-only).
- Thêm `registry/param_to_threshold_map.yaml` để nối **ngưỡng (threshold)** với **Param_Code** (tránh hard-code).
- Bổ sung demo inputs cho finance ledger + log append-only (audit/*.jsonl) để theo dõi kill-switch/quarantine.
- Đã có `validate_registry.py` lint thêm cho: DSL V1, event_code tồn tại, threshold-param hợp lệ.

## Cập nhật P8 (27/12/2025)
- Vá lỗi Excel mở CSV tiếng Việt bị bể font: thêm **UTF-8 BOM** cho 3 file registry CSV: `metrics.csv`, `formulas.csv`, `glossary.csv`.
- Đồng bộ BOM ở cả 2 nơi: `03_Registry/registry/` và `02_Repo_Complete/d2com-pilot-yen-lac/registry/`.
- Regen `MANIFEST_FILES.txt` + `MANIFEST_SHA256.txt`.

## Cập nhật P9 (28/12/2025)
- Vá `DEMO_RUN.md` để chạy không gãy (template_code đúng: `A7_events_evt_star`) và thống nhất demo chạy theo **canonical demo store**.
- Thêm `READY_DEMO_30` KPI pack (allowlist 30 KPI) + script smoke test.
- Bổ sung demo events để qua schema validation (đủ required_keys), giúp KPI pack ra số.
- Thêm derived tables builder (`build_demo_store.py`) + unit tests/smoke tests (`pytest -q`).
