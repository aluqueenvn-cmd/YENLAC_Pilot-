# Completeness checklist — P6 (2025-12-27)

- [x] Folder 07 & 09: filenames recovered to UTF-8 Vietnamese where garbled
- [x] Folder 07 & 09: DOCX font normalized to Calibri (styles + runs + header/footer)
- [x] Patch ledger entry added (P6)
- [x] MANIFEST_FILES regenerated
- [x] MANIFEST_SHA256 regenerated

