# P8-REGISTRY-CSV-UTF8BOM (V5.0.2) — 2025-12-27

## Mục tiêu
- Sửa lỗi hiển thị tiếng Việt khi mở các file CSV trong Excel/Windows (do CSV UTF-8 không có BOM).
- **Không thay đổi nội dung logic** của các registry CSV.

## Phạm vi tác động
- Folder `03_Registry/registry/`:
  - `metrics.csv`
  - `formulas.csv`
  - `glossary.csv`
- Repo registry mirror:
  - `02_Repo_Complete/d2com-pilot-yen-lac/registry/metrics.csv`
  - `02_Repo_Complete/d2com-pilot-yen-lac/registry/formulas.csv`
  - `02_Repo_Complete/d2com-pilot-yen-lac/registry/glossary.csv`

## Thay đổi
- Thêm UTF-8 BOM (byte order mark) `EF BB BF` ở đầu file để Excel tự nhận đúng UTF-8.
- Giữ nguyên toàn bộ dòng/cột, delimiter, và nội dung văn bản.

## Kiểm soát lỗi logic
- Không đổi schema.
- Không đổi số dòng.
- Chỉ thay đổi 3 byte đầu file (BOM).
