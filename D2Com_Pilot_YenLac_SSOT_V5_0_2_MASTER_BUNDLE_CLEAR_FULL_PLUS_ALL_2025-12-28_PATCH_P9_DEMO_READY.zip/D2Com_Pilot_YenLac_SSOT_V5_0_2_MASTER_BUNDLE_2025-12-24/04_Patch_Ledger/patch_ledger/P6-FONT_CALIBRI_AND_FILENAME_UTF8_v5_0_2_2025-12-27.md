# P6 — Font Calibri + UTF-8 filenames (Folder 07 & 09) — v5.0.2 — 2025-12-27

## Mục tiêu
1) Chuẩn hoá hiển thị tài liệu Word (DOCX) về font **Calibri** để giảm lệch layout giữa các máy/phiên bản Office.
2) Sửa lỗi tên file bị lỗi mã hoá (garbled/encoding) trong **07_Input_Data_Sources** và **09_Reference_Docs** về đúng tiếng Việt UTF-8.

## Phạm vi thay đổi (scope)
- Chỉ tác động **Folder 07** và **Folder 09** trong bundle.
- Không thay đổi nội dung logic nghiệp vụ; chỉ thay đổi **trình bày (presentation)** và **tên file**.

## Các file đổi tên (filename fix)
### 07_Input_Data_Sources
- `VDCD - BΓö£├╝O GIΓö£├╝ KS 6 XΓö£├ó 18122025.xlsx` → `VDCD - BÁO GIÁ KS 6 XÃ 18122025.xlsx`
- `VDCD - BΓö£├╝O GIΓö£├╝ ChuanHoaDuLieu - PhanGiaiDoan.xlsx` → `VDCD - BÁO GIÁ ChuanHoaDuLieu - PhanGiaiDoan.xlsx`
- `Ph├ƒΓòù├æ l├ƒΓòù├æc Data- House ID ( AUSTDOOR ).docx` → `Phụ lục Data- House ID ( AUSTDOOR ).docx`

### 09_Reference_Docs
- `ΓöÇ├ë├ƒΓòù├ç CΓò₧┬╗Γò₧├íNG D├ƒΓòùΓûæ Γö£├╝N D2comS2b2v3.docx` → `ĐỀ CƯƠNG DỰ ÁN D2comS2b2v3.docx`
- `Master_Glossary_D2Com_S2B2C_v5 ( ch├ƒΓòù├ªt ).docx` → `Master_Glossary_D2Com_S2B2C_v5 ( chốt ).docx`
- `KI├ƒΓòæΓò¢N TRΓö£├£C DATA.docx` → `KIẾN TRÚC DATA.docx`

## Chuẩn hoá font (DOCX)
Các tài liệu DOCX trong Folder 07 & 09 được chuẩn hoá:
- **Mọi style** (Normal/Heading/Title/Character styles) → Calibri
- **Mọi run text** trong body, bảng, header/footer → Calibri
- Đặt cả `ascii/hAnsi/cs/eastAsia` về Calibri để giảm lỗi fallback font.

Danh sách DOCX đã xử lý:
- 07_Input_Data_Sources/Phu_luc_danh_muc_du_lieu.docx
- 07_Input_Data_Sources/Phụ lục Data- House ID ( AUSTDOOR ).docx
- 09_Reference_Docs/Playbook_V4_Final_Gov_YenLac_2026_Bilingual_Glossary_NoCrop.docx
- 09_Reference_Docs/D2Com_Data_Dictionary_v2_HouseID_ParcelID_AssetID.docx
- 09_Reference_Docs/Phu_luc_danh_muc_du_lieu.docx
- 09_Reference_Docs/ĐỀ CƯƠNG DỰ ÁN D2comS2b2v3.docx
- 09_Reference_Docs/Master_Glossary_D2Com_S2B2C_v5 ( chốt ).docx
- 09_Reference_Docs/KIẾN TRÚC DATA.docx

## Tác động
- **Tài liệu/hiển thị:** giảm nguy cơ tràn bảng, trôi trang, lệch mục lục do thay font.
- **Hệ thống tính KPI/Streamlit:** không ảnh hưởng (không parse DOCX để tính KPI).

## Kiểm soát chất lượng
- Regenerate lại:
  - `00_README/MANIFEST_FILES.txt`
  - `00_README/MANIFEST_SHA256.txt`

