# P3 – Board dashboard + Consent + Integrity + API (V5.0.2)

Ngày: 2025-12-26 (Asia/Bangkok)

## 1) Bổ sung cho HĐQT
- Streamlit page mới:
  - `00A_User_Guide.py` (Hướng dẫn đọc số)
  - `09_HDQT_View_K0_K8.py` (HĐQT view theo cây K0–K8)
  - `10_HouseID_StateMachine.py` (state machine trực quan)
- Tài liệu mới:
  - `docs/board/HOUSE_ID_STATE_MACHINE.md`
  - `docs/board/KILL_SWITCH_CONSENT_RISK.md`

## 2) Consent kill-switch (khóa dừng vì PII)
- Ingest chặn record có `pii_*` mà `consent_flag != true` (quarantine, không lưu PII).
- Bổ sung `registry/retention_policy.yaml` + `docs/governance/RETENTION_POLICY.md`.

## 3) Integrity (append-only)
- Bổ sung hash chain: `data/event_store/event_log_hashchain.jsonl`.
- Script kiểm: `code/scripts/verify_event_log_integrity.py`.

## 4) API contract
- `docs/api/OPENAPI_event_ingest_v5_0_2.yaml` + `docs/api/README.md`.

## 5) Ops tiện dụng
- `code/core/alerting.py` + `registry/alert_routes.yaml`.
- Dockerfile + docker-compose + .env.example.
- Repo hygiene lint: `code/scripts/repo_hygiene_lint.py`.

## 6) Lưu ý tương thích
- Không đổi cấu trúc thư mục cũ. Chỉ **thêm** file/page/script.
- Các KPI hiển thị HĐQT hiện lấy từ event log demo; metric chưa có dữ liệu sẽ hiển thị **N/A**.
