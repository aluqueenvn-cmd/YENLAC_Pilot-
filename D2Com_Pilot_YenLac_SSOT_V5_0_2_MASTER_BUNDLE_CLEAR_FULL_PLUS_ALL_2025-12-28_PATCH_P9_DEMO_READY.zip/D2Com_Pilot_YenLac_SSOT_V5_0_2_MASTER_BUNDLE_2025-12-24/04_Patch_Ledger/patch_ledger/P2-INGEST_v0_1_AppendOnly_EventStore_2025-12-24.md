# P2-INGEST v0.1 — Append-only Ingest Pipeline (nạp sự kiện) — 2025-12-24

## 1) Summary (tóm tắt)
- Thêm ingest pipeline (nạp sự kiện) **file-based** để pilot chạy nhanh: validate theo registry, chống ghi trùng, quarantine, audit.
- Thêm CLI nạp CSV + unit test.

## 2) LOCKED compliance (tuân thủ quyết định đã khóa)
- Không đổi House_ID state machine 5 trạng thái UPPERCASE.
- Không đổi chuẩn event_code `EVT_*`, vẫn bắt buộc `idempotency_key`.
- Consent/PII: nếu `consent_flag==False` thì không lưu `pii_*` (tối thiểu).
- Không can thiệp Gate “No Evidence + Bad Evidence No Pay”.

## 3) Files added (đã thêm)
Trong repo: `02_Repo_Complete/d2com-pilot-yen-lac/`
- `code/core/ingest_pipeline.py`
- `code/scripts/ingest_events.py`
- `docs/ingest_contract.md`
- `tests/test_ingest_pipeline.py` + `tests/conftest.py`

## 4) Outputs (append-only)
Sinh ra khi chạy ingest:
- `data/event_store/event_log.jsonl`
- `data/event_store/idempotency_keys.txt`
- `data/quarantine/quarantine_events.jsonl`
- `data/audit/ingest_audit.jsonl`

## 5) Tests
- `python code/scripts/validate_registry.py --repo_root .` => PASS
- `pytest -q` => PASS

## 6) Giới hạn v0.1
- Chưa có JSONSchema chi tiết theo type/unit; v0.1 mới check required_keys + format căn bản.
- Chưa có event store production (DB/stream). V0.1 là file-based để pilot chạy nhanh.
