# P2-TEMPLATES-MATRIX v0.2 — Clarify PII/Scoring/Influence (Ngày 2025-12-25)

## Mục tiêu
Khóa ma trận template GĐ1 theo SSOT V5.0.2, vá 3 điểm mơ hồ do đánh giá thực địa:
1) A3 Job Master: phân loại dữ liệu (PII vs non-PII) và bổ sung cột role-owner theo job.
2) B2/B3 Gov: thêm điểm số (1–5) + reason_code để giảm chủ quan.
3) B9/B10 Influence: tránh duplicate với actor_master; thêm entity_type cho edges.

## LOCKED không đổi
- Append-only: không sửa lịch sử; chỉ thêm bản ghi mới.  
- Event canonical EVT_* + idempotency_key.  
- Provider-neutral: provider_raw tách canonical.  
- Consent/PII: không lưu PII khi chưa consent; chỉ dùng *_ref trỏ PII Vault.

## Thay đổi cụ thể

### (1) A3 — TMP_JOB_MASTER
- File: `templates/hard/job_master.csv`
- Thêm cột: `ust_actor_id`, `field_runner_actor_id`, `adg_actor_id`
- Giữ `assigned_actor_id` để tương thích (alias/legacy).
- Ghi chú phân loại: `*_actor_id` là mã nội bộ (không phải PII). PII thật nằm ở `*_ref` và chỉ được phép sau consent.

### (2) B2/B3 — TMP_GOV_STAKEHOLDER_MAP / TMP_GOV_ENGAGEMENT_LOG
- File: `templates/soft/gov_stakeholder_map.csv`
  - Thêm: `stance_score` (1–5), `outcome_reason_code`
- File: `templates/soft/gov_engagement_log.csv`
  - Thêm: `meeting_outcome_score` (1–5), `outcome_reason_code`
- Cập nhật dimension:
  - `DIM_OUTCOME_REASON_CODE`: POLITICAL/TECHNICAL/LACK_BUDGET/COMPLIANCE/OTHER
  - `DIM_OUTCOME`: OK/PENDING/RESIST

### (3) B9/B10 — TMP_INFLUENCE_NODE_REGISTRY / TMP_INFLUENCE_EDGES
- File: `templates/soft/influence_node_registry.csv`
  - Thêm: `actor_id` (optional). Nếu node đã tồn tại trong actor_master thì điền actor_id để tránh trùng.
- File: `templates/soft/influence_edges.csv`
  - Thêm: `from_entity_type`, `to_entity_type`
- Cập nhật dimension:
  - `DIM_ENTITY_TYPE`: HOUSE_ID/HOUSE_CLUSTER/ACTOR_ID/INFLUENCE_NODE/GOV_CONTACT/GEO_UNIT

## File bị tác động
- `registry/template_registry.yaml`
- `registry/intel_dimensions.yaml`
- `templates/hard/actor_master.csv`
- `templates/hard/job_master.csv`
- `templates/soft/gov_stakeholder_map.csv`
- `templates/soft/gov_engagement_log.csv`
- `templates/soft/influence_node_registry.csv`
- `templates/soft/influence_edges.csv`
- `docs/templates/template_matrix_v5_0_2.md`
- `docs/templates/excel_master_tabs_v0_1.md`

## Kiểm thử tối thiểu
- CSV vẫn đúng header, có 1 dòng ví dụ.
- Dimension mới không phá dimension cũ (chỉ append).

