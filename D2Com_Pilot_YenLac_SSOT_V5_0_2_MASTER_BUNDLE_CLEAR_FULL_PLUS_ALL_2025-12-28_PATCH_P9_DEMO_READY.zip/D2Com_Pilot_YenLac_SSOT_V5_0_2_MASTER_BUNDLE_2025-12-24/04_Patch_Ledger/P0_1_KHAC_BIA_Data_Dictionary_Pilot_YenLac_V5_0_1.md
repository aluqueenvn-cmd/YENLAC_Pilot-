# P0.1 - KHẮC BIA - Master Data Dictionary + Naming Contract - Pilot D2Com Yên Lạc - V5.0.1

## Chốt quyết định
- house_lifecycle_status: ENUM UPPERCASE (SHADOW -> QUALIFIED -> CLAIMED -> FINANCIAL -> GOLDEN)
- data_verify_level != verification_level_v2
- Bắt buộc pilot: construction_stage, expected_completion_date, unit_id

## P0.1 bổ sung
- Alias governance + linter + sunset
- Tiered kill-switch (Warning/Throttle/Hard Stop)
- Business calendar registry (SLA theo business-time)
- Finance lineage minimum (recompute policy)
- Evidence chain-of-custody + consent snapshot + quarantine budget

## Tiered Kill-switch (example)
```yaml
kill_switch_tiers:
  tier_1_warning:
    trigger: "payload_schema_reject_rate_pct > 2 for 60m"
    action: "Alert Risk Lead + Data Lead"
    owner: "Head of Risk"
  tier_2_throttle:
    trigger: "fake_evidence_rate_pct > 5 for 30m"
    action: "Pause new lead allocation; quarantine pending payout"
    owner: "CFO"
  tier_3_hard_stop:
    trigger: "unconsented_pii_risk > 0 OR fake_evidence_rate_pct > 10 for 15m"
    action: "Disable payout API; freeze pilot; trigger war-room"
    owner: "CEO/Commander"
```

## Business calendar (versioned)
```yaml
business_calendar_registry:
  calendar_version: "VN_2026_v1"
  timezone: "Asia/Ho_Chi_Minh"
  business_hours: "08:00-18:00"
  business_days: "Mon-Sat"
  sla_clock_rule: "Only count business time"
```

## Finance lineage minimum
```yaml
finance_lineage_min:
  discount_rate_pct:
    downstream: ["avg_selling_price_vnd","l1_margin_vnd","split_residual_vnd"]
    recompute_policy: "recompute all downstream within 1h"
  dso_days:
    downstream: ["cash_cycle_days","runway_days"]
    recompute_policy: "recompute within 30m"
```

## Quarantine policy
```yaml
quarantine_policy:
  queue_limit_events: 5000
  ttl_days_default: 14
  auto_purge: true
  reprocess_policy:
    max_reprocess_attempts: 2
    require_owner_signoff: true
```
