# P5 | 2025-12-27 | FIX1 (Logic & Hygiene)

## 1) Fix lỗi logic (đang gây crash / sai KPI)
- Sửa **NameError** trong `code/core/asset_loader.py` (dòng cache dùng biến `table` không tồn tại).
- Sửa công thức KPI **vdcd_pack_completion_rate** (F-A1-VDCD-01) bị sai *numerator/denominator*.
  - Numerator: House_ID có event `EVT_DISC_VDCD_PACK_CREATED` hoặc `EVT_DISC_VDCD_API_PUBLISHED`
  - Denominator: House_ID có event `EVT_DISC_DRONE_SCAN_CREATED` hoặc `EVT_DISC_LEGACY_IMPORT_CREATED`

## 2) Vá vendor lock-in theo P0-02 (trung tính nhà cung cấp)
- Tạo KPI canonical: **survey_pack_completion_rate** (F-A1-SURVEY-01).
- Gắn alias: `vdcd_pack_completion_rate -> survey_pack_completion_rate` trong `metric_alias.yaml`.
- Đồng bộ thay đổi ở cả:
  - `03_Registry/registry/*`
  - `02_Repo_Complete/d2com-pilot-yen-lac/registry/*`

## 3) Hygiene (tránh “rác build” chui vào SSOT)
- Loại bỏ `__pycache__/` và `*.pyc` khỏi bundle.

## 4) Audit
- Không chỉnh sửa nội dung các file `.docx` gốc (byte-identical so với base zip).

## 5) Manifest
- Regenerate `00_README/MANIFEST_FILES.txt` và `00_README/MANIFEST_SHA256.txt` sau khi vá.

