# Appendix A5 – Data Dictionary (Khắc Bia) – Canonical Index (V5.0.2)

## Mục đích
Appendix A5 (Khắc Bia Data Dictionary) là **đinh nghĩa dữ liệu chuẩn** (canonical) cho Pilot Yên Lạc.
Trong gói này, A5 canonical được cấu thành theo nguyên tắc **append-only** từ các bản sau:

## Thành phần A5 canonical trong bundle
1) **P0.1 – Khắc Bia Data Dictionary V5.0.1 (MetadataFixed 24/12/2025)**
- File: `04_Patch_Ledger/P0_1_KHAC_BIA_Data_Dictionary_Pilot_YenLac_V5_0_1.(docx|md)`
- File: `04_Patch_Ledger/P0_1_KHAC_BIA_V5_0_1_MetadataFixed_2025-12-24.(docx|md)`

2) **P0-DATA-AGE – House Age (Tuổi nhà) bổ sung append-only**
- File: `04_Patch_Ledger/P0-DATA-AGE.(docx|md)`

## A5 source (bằng chứng gốc)
- File: `06_Source_Appendix_Raw/Master_Data_Dictionary_KhacBia_D2Com_YenLac_v1_2_PATCH_18Logic_v2_0.docx`

## Ghi chú
- Đây là file **index** để người đọc không bị loạn. Nội dung chuẩn nằm trong các file P0.1 và P0-DATA-AGE.
