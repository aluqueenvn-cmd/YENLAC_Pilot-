# Templates GD1 (V5.0.2)

- EXCEL: cho người chạy cơm
- TEMPLATEPACKS: cho máy đọc (CSV mẫu + schema.yaml + README)
- Không sửa nội dung gốc SSOT/Appendix. Chỉ bổ sung deliverables.
